﻿using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces
{
    public interface IUserLoginRepository
    {
        Task<IEnumerable<CompanySignUpInfo>> ValidateUserCredentials(LoginInfo loginCredentials);

        Task<IEnumerable<CompanySignUpInfo>> GetAllCompanies();
    }
}
