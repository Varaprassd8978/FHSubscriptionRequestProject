﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class Address
    {
       //[Required]
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
       //[Required]
        public string City { get; set; }
      //[Required]
        public string State { get; set; }
      //[Required]
        public string Country { get; set; }
     // [Required]
      //[StringLength(6)]
        public string PostalCode { get; set; }

        public override string ToString()
        {
            return string.Format(@"{0}, {1}, {2}, {3}, {4}, {5}",

                this.AddressLine1, this.AddressLine2, this.City, this.State, this.Country, this.PostalCode).ToString();
        }
    }
}
