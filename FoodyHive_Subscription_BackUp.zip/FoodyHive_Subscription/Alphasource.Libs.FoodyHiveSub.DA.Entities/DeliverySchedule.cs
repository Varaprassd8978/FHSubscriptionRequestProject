﻿namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class DeliverySchedule
    {
        public Schedule[] schedules { get; set; }
    }
}