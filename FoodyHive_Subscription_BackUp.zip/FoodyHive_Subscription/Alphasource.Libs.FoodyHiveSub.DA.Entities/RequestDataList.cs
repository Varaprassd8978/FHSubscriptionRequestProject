﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class RequestDataList
    {
        public List<SubscriptionRequest> RequestsList { get; set; }

        public List<CompanyQuickInfo> ComapnyData { get; set; }
    }
}
