﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alphasource.Libs.FoodyHiveSub.Models
{
    public class UserSubscriptionModel
    {
        public string UserSubscriptionId { get; set; }        
        public string SubscriberName { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public Address[] FullAddress { get; set; }
        public string SubscriptionPlan { get; set; }
        public DateTime DataOfSubscription { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }              
    }
}
