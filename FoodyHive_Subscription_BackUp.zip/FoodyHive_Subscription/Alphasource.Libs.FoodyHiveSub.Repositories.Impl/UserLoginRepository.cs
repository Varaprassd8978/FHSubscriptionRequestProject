﻿using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;
using Alphasource.Libs.FoodyHiveSub.DA.Interfaces;

namespace Alphasource.Libs.FoodyHiveSub.Repositories.Impl
{
    public class UserLoginRepository : IUserLoginRepository
    {
        private const int MAX_ITEMS_TO_FETCH = 5000;
        private TableStorageSettings tableStorageSettings = default;
        private CloudStorageAccount cloudStorageAccount = default;
        private CloudTableClient cloudTableClient = default;        
        private CloudTable cloudTable = default;

        private ISubscriptionRequestRepository subRequest = default(ISubscriptionRequestRepository);
        private ICompanySignUpRepository _companyRepo = default;

        public UserLoginRepository(ISubscriptionRequestRepository subscriptionRequest, ICompanySignUpRepository companySignUpRepository,TableStorageSettings tableStorageSettings)
        {
            this.subRequest = subscriptionRequest;
            this._companyRepo = companySignUpRepository;
            var validateConnection = tableStorageSettings != default &&
               !string.IsNullOrEmpty(tableStorageSettings.ConnectionString) &&
               !string.IsNullOrEmpty(tableStorageSettings.TableName);

            if (!validateConnection)
            {
                throw new ArgumentException("INVALID_TABLE_STORAGE_SETTINGS");
            }

            this.tableStorageSettings = tableStorageSettings;
            this.cloudStorageAccount = CloudStorageAccount.Parse(this.tableStorageSettings.ConnectionString);
            this.cloudTableClient = this.cloudStorageAccount.CreateCloudTableClient();
            this.cloudTable = this.cloudTableClient.GetTableReference("companySignUptableV2");


        }       

        //public async Task<IEnumerable<SubscriptionRequest>> GetSubscriptionData()
        //{
        //    return await this.subRequest.GetAllSubscribersList();
        //}


        public async Task<IEnumerable<CompanySignUpInfo>> GetAllCompanies() {

            return await this._companyRepo.GetAllCompaniesList();
        
        }

        public async Task<IEnumerable<CompanySignUpInfo>> ValidateUserCredentials(LoginInfo loginCredentials)
        {
           // var result = default(dynamic);
            //string comapnyCode = default(string);
            //string password = default(string);

            var companyDataEntity = new List<CompanySignUpInfo>();

            //var requestList = this.GetAllCompanies();
            //var requestResult = requestList.Result;

            //foreach (var item in requestResult)
            //{
            //    if (item.CompanyCode == loginCredentials.CompanyCode && item.Password == loginCredentials.Password)
            //    {
                    var comapnyCode = TableQuery.GenerateFilterCondition("CompanyCode", QueryComparisons.Equal, loginCredentials.CompanyCode);
                    var password = TableQuery.GenerateFilterCondition("Password", QueryComparisons.Equal, loginCredentials.Password);
                    var combinedFilters = default(string);


                    combinedFilters = TableQuery.CombineFilters(comapnyCode, TableOperators.And, password);

                    var query = new TableQuery<CompanySignUpInfo>()
                      .Where(combinedFilters)
                      .Take(MAX_ITEMS_TO_FETCH);

                    var Token = default(TableContinuationToken);

                    do
                    {
                        var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<CompanySignUpInfo>(query, Token);

                        //if (queryResult.Results.Count == 0)
                        //{
                        //    throw new Exception("No Data Found");
                        //}

                        foreach (var item1 in queryResult.Results)
                        {
                            var companyAddress = JsonConvert.DeserializeObject<Address>(item1.FullAddress);
                            item1.CAddress = companyAddress;
                        }

                        companyDataEntity.Capacity += queryResult.Results.Count;
                        companyDataEntity.AddRange(queryResult.Results);
                        Token = queryResult.ContinuationToken;

                        if (Token != null && query.TakeCount.HasValue)
                        {
                            var itemsToLoad = query.TakeCount.Value - companyDataEntity.Count;

                            query = itemsToLoad > 0 ? query.Take(itemsToLoad) : null;
                        }

                    } while (Token != null && query != null);

                    //result =  companyDataEntity;
            //    }                
            //}

            //comapnyCode = TableQuery.GenerateFilterCondition("CompanyCode", QueryComparisons.Equal, loginCredentials.CompanyCode);
            //password = TableQuery.GenerateFilterCondition("Password", QueryComparisons.Equal, loginCredentials.Password);

            return companyDataEntity;
           
        }

    }
    
}
