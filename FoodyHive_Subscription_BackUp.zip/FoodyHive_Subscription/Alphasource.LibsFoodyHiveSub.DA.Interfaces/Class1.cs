﻿using System;

namespace Alphasource.LibsFoodyHiveSub.DA.Interfaces
{
    public class Class1
    {
    }
}
