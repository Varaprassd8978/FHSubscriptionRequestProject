﻿using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.DA.Interfaces;
using Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Repositories.Impl
{
    public class CompanySignUpRepository : ICompanySignUpRepository
    {
        private const string INVALID_TABLE_STORAGE_SETTINGS = "Invalid SubscriptionRequest Table Storage Settings Specified!";
        private const int MAX_ITEMS_TO_FETCH = 5000;
        private TableStorageSettings tableStorageSettings = default;
        private CloudStorageAccount cloudStorageAccount = default;
        private CloudTableClient cloudTableClient = default;
        private CloudTable cloudTable = default;

        public CompanySignUpRepository(TableStorageSettings tableStorageSettings)
        {
            var validateConnection = tableStorageSettings != default &&
                !string.IsNullOrEmpty(tableStorageSettings.ConnectionString) &&
                !string.IsNullOrEmpty(tableStorageSettings.TableName);

            if (!validateConnection)
            {
                throw new ArgumentException(INVALID_TABLE_STORAGE_SETTINGS);
            }

            this.tableStorageSettings = tableStorageSettings;
            this.cloudStorageAccount = CloudStorageAccount.Parse(this.tableStorageSettings.ConnectionString);
            this.cloudTableClient = this.cloudStorageAccount.CreateCloudTableClient();          
            this.cloudTable = this.cloudTableClient.GetTableReference("companySignUptableV2");

            CreateNewTable(cloudTable);

        }


        /// <summary>
        /// Create the New Azure Table Storage in the Azure Storage Account if Not Exists
        /// </summary>
        /// <param name="table"></param>
        /// 
        public async static void CreateNewTable(CloudTable table)
        {
            if (!await table.CreateIfNotExistsAsync())
            {
                Console.WriteLine("Table already exists");
                return;
            }            
        }

        public async Task<CompanySignUpInfo> Create(CompanySignUpInfo companyInfo)
        {
            var status = default(bool);
            var result = default(CompanySignUpInfo);

            var existingData = await this.GetAllCompaniesList();

            foreach(var data in existingData)
            {
               if(companyInfo.CompanyName == data.CompanyName ||
                    companyInfo.EmailId == data.EmailId ||
                    companyInfo.PhoneNumber == data.PhoneNumber)
                {
                    throw new ApplicationException("The Company Details Already Exists!");
                }
            }


            //Region generates the CompanyID,Company Code and Password and will set the IsAdmin = flase.
            #region
            {
                string date = DateTime.Now.ToString("ddMMyyyyHHmmss");

                string finalStr = "CMPNY" + date;

                companyInfo.CompanyId = finalStr;

                companyInfo.PartitionKey = companyInfo.CompanyName;

                companyInfo.RowKey = companyInfo.CompanyId;

                companyInfo.ETag = new Random().Next(1, 10000000).ToString();


                var numberString = companyInfo.PhoneNumber;
                string newRandomOddIndexCharString = default(string);
                for (int i = 0; i < numberString.Length; i++)
                {
                    if (i % 2 == 1)
                    {
                        continue;
                    }
                    newRandomOddIndexCharString += numberString[i];
                }
                Console.WriteLine(newRandomOddIndexCharString);

                var companySplit = default(string[]);
                var characters = default(string);
                if (companyInfo.CompanyName.Contains(" "))
                {
                    companySplit = companyInfo.CompanyName.Split(" ");
                    foreach (var item in companySplit)
                    {
                        characters += item.Substring(0, 2);
                        Console.WriteLine(characters);
                    }
                }
                else
                {
                    characters += companyInfo.CompanyName.Substring(0, 4);
                }

                companyInfo.CompanyCode = characters.ToUpper() + newRandomOddIndexCharString;
                Console.WriteLine(companyInfo.CompanyCode);
                var passwordStr = companyInfo.SubscriberName.Substring(0, 4);
                companyInfo.Password = passwordStr + Guid.NewGuid().ToString("d").Substring(1, 6);
                Console.WriteLine(companyInfo.Password);

                companyInfo.IsAdmin = false;
                companyInfo.EmailFlag = "N";
            }
            #endregion

          
            
          var validation = companyInfo != default(CompanySignUpInfo) &&
                   !string.IsNullOrEmpty(companyInfo.CompanyName) &&
                 !string.IsNullOrEmpty(companyInfo.CompanyCode);

            if (!validation)
                throw new ArgumentException("Invalid Company Details Entity");


            var tableOperation = TableOperation.Insert(companyInfo);
            var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);


            result = (CompanySignUpInfo)tableResult.Result;
            var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };

            status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);

            return result;
        }

        public async Task<List<CompanySignUpInfo>> GetAllCompaniesList()
        {
            var query = new TableQuery<CompanySignUpInfo>();

            var Token = default(TableContinuationToken);
            var companyDataEntities = new List<CompanySignUpInfo>();

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<CompanySignUpInfo>(query, Token);
                if (queryResult.Results.Count == 0)
                {
                    throw new Exception("No Data Found");
                }

                foreach (var item in queryResult.Results)
                {
                    if (item.FullAddress != null)
                    {
                        var companyAddress = JsonConvert.DeserializeObject<Address>(item.FullAddress);
                        item.CAddress = companyAddress;
                    }
                }
                    companyDataEntities.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;
            } while (Token != null);

            return companyDataEntities;
        }

        public async Task<List<CompanySignUpInfo>> GetCompanyDetailsById(string companyId)
        {

            var validation = !string.IsNullOrEmpty(companyId);
            var companyDataEntities = new List<CompanySignUpInfo>();

            if (!validation)
                throw new ArgumentException("Invalid Arguments");

            var queryCondition = TableQuery.GenerateFilterCondition("CompanyId", QueryComparisons.Equal, companyId);

            var query = new TableQuery<CompanySignUpInfo>().Where(queryCondition).Take(MAX_ITEMS_TO_FETCH);


            var Token = default(TableContinuationToken);

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<CompanySignUpInfo>(query, Token);
                if (queryResult.Results.Count == 0)
                {
                    throw new Exception("No Data Found");
                }

                foreach (var item in queryResult.Results)
                {
                    if (item.FullAddress != null)
                    {
                        var companyAddress = JsonConvert.DeserializeObject<Address>(item.FullAddress);
                        item.CAddress = companyAddress;
                    }
                }
                companyDataEntities.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;
            } while (Token != null);

            return companyDataEntities;
        }



        public async Task<List<CompanySignUpInfo>> GetCompanyDataByID(string companyId)
        {

            var validation = !string.IsNullOrEmpty(companyId);
            var companyDataEntities = new List<CompanySignUpInfo>();

            if (!validation)
                throw new ArgumentException("Invalid Arguments");

            var queryCondition = TableQuery.GenerateFilterCondition("CompanyId", QueryComparisons.Equal, companyId);

            var query = new TableQuery<CompanySignUpInfo>().Where(queryCondition).Take(MAX_ITEMS_TO_FETCH);


            var Token = default(TableContinuationToken);

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<CompanySignUpInfo>(query, Token);               
                //foreach (var item in queryResult.Results)
                //{
                //    if (item.FullAddress != null)
                //    {
                //        var companyAddress = JsonConvert.DeserializeObject<Address>(item.FullAddress);
                //        item.CAddress = companyAddress;
                //    }
                //}
                companyDataEntities.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;
            } while (Token != null);

            return companyDataEntities;
        }

        public async Task<CompanySignUpInfo> ReteriveScheduleData(string partitionKey, string rowKey)
        {
            TableOperation tableOperation = TableOperation.Retrieve<CompanySignUpInfo>(partitionKey, rowKey);
            TableResult tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
            return (CompanySignUpInfo)tableResult.Result;
        }

        public async Task<bool> DeleteCompany(string companyName, string companyId)
        {
            var status = default(bool);
            var validation = !string.IsNullOrEmpty(companyName) &&
                                !string.IsNullOrEmpty(companyId);

            if (!validation)
                throw new ArgumentException("Invalid Arguments!.");

            // var tableOperation = default(dynamic);
            var tableEntity = await this.ReteriveScheduleData(companyName, companyId);

            var tableOperation = TableOperation.Delete(tableEntity);
            var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
            var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };

            status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);
            return status;
        }



        public async Task<bool> UpdateComapnyRoleToAdmin(string companyId, bool IsAdmin)
        {
            var IsValid = !string.IsNullOrEmpty(companyId);
            var status = default(bool);

            var existingData = await this.GetCompanyDetailsById(companyId);

            // var IsCompanyAdminOrNot = default(bool);

            //foreach (var item in existingData)
            //{
            //    IsCompanyAdminOrNot = item.IsAdmin;
            //}

            //if(IsCompanyAdminOrNot == true)
            //{
            var tableOperation = default(dynamic);
            foreach (var item in existingData)
            {
                item.IsAdmin = IsAdmin;
                tableOperation = TableOperation.Replace(item);
            }
            var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
            var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };

            status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);

            return status;
            //}
            //else
            //{
            //    throw new Exception("Your are not a Authorized User to perform this action.Since, User is not a admin.");
            //}

        }

        private async Task<bool> IsUserAdminOrNot(string companyId)
        {
            var IsValid = !string.IsNullOrEmpty(companyId);

            if (!IsValid)
                throw new ArgumentException("Invalid CompanyID");

            var companyDataById = await this.GetCompanyDetailsById(companyId);

            var IsUserAdmin = default(bool);
            foreach (var item in companyDataById)
            {

                IsUserAdmin = item.IsAdmin;
            }

            return IsUserAdmin;
        }

        public async Task<List<CompanyQuickInfo>> GetCompanyDetailsBySearch(string companyId,string searchString)
        {
          //  var validation = !string.IsNullOrEmpty(searchString);

            var companyDataEntities = new List<CompanySignUpInfo>();
            var companyQuickInfo = new List<CompanyQuickInfo>();

            //if (!validation)
            //    throw new ArgumentException("Invalid Arguments");

            var combinedFilters = default(string);
            var queryCondition = TableQuery.GenerateFilterCondition("CompanyId", QueryComparisons.Equal, companyId);
            var RegEx = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
            var phoneNoRegx = @"^[0-9]*$";
            if (Regex.IsMatch(searchString, RegEx, RegexOptions.IgnoreCase))
            {
                var emailQuery = TableQuery.GenerateFilterCondition("EmailId", QueryComparisons.Equal, searchString);
                combinedFilters = TableQuery.CombineFilters(companyId, TableOperators.And, emailQuery);
            }
            else if (Regex.IsMatch(searchString, phoneNoRegx, RegexOptions.IgnoreCase))
            {
                var numberQuery = TableQuery.GenerateFilterCondition("PhoneNumber", QueryComparisons.Equal, searchString);
                combinedFilters = TableQuery.CombineFilters(companyId, TableOperators.And, numberQuery);
            }
            else
            {
                var companyNameQuery = TableQuery.GenerateFilterCondition("CompanyName", QueryComparisons.Equal, searchString);
                var subscriberNameQuery = TableQuery.GenerateFilterCondition("SubscriberName", QueryComparisons.Equal, searchString);

                combinedFilters = TableQuery.CombineFilters(
                        TableQuery.CombineFilters(
                            queryCondition,
                            TableOperators.And,
                            companyNameQuery),
                        TableOperators.Or, subscriberNameQuery);
               // combinedFilters = TableQuery.CombineFilters(companyNameQuery, TableOperators.Or, subscriberNameQuery);
            }

            var query = new TableQuery<CompanySignUpInfo>()
               .Where(combinedFilters)
               .Take(MAX_ITEMS_TO_FETCH);

            var Token = default(TableContinuationToken);

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<CompanySignUpInfo>(query, Token);
                foreach (var data in queryResult.Results)
                {
                    // companyQuickInfo.AddRange((IEnumerable<CompanyQuickInfo>)queryResult.Results);
                    companyQuickInfo.Add(new CompanyQuickInfo
                    {
                        CompanyId = data.CompanyId,
                        CompanyName = data.CompanyName,
                        SubscriberName = data.SubscriberName,
                        EmailId = data.EmailId,
                        PhoneNumber = data.PhoneNumber
                    });
                }
                Token = queryResult.ContinuationToken;
            } while (Token != null);

            return companyQuickInfo;
        }
    }
}




