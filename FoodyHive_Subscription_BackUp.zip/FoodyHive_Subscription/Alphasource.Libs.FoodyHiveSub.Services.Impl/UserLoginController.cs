﻿using Alphasource.Libs.FoodyHiveSub.Business.Interfaces;
using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.Utilities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Services.Impl
{

    /// <summary>
    /// User Loign API Controller
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class UserLoginController : ControllerBase
    {
        private IUserLoginService _userLoginService = default(IUserLoginService);

        private IConfiguration _configuration = default(IConfiguration);


        /// <summary>
        /// Loign Controller Primary Constructor
        /// </summary>
        /// <param name="userLoginService"></param>
        public UserLoginController(IUserLoginService userLoginService, IConfiguration configuration)
        {
            if (userLoginService == default(IUserLoginService))
                throw new ArgumentException(nameof(userLoginService));

            this._userLoginService = userLoginService;

            if (configuration == default(IConfiguration))
                throw new ArgumentException(nameof(configuration));


            this._configuration = configuration;
        }


        /// <summary>
        /// User Login 
        /// </summary>
        /// <param name="loginInfo"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("userlogin")]
        public async Task<IActionResult> Login(LoginInfo loginInfo)
        {
            var result = (IActionResult)Unauthorized();

            try
            {
                validateLogin(loginInfo);               
                
                var authenticatedUserInfo = await this._userLoginService.ValidateUserCredentials(loginInfo);

                if (authenticatedUserInfo != default(CompanySignUpInfo))
                {
                    var token = GenerateWedToken(authenticatedUserInfo);

                    //var decodeData = Encoding.UTF8.GetBytes(authenticatedUserInfo);

                    result = Ok(new Response
                    {
                        IsSuccess = true,
                        SuccessMessage = "Successfully token Generated.",
                        Token = token,
                        data = authenticatedUserInfo
                    });
                }               
                
            }
            catch(Exception exObj)
            {
                Console.WriteLine("Application", "Error Occured Details : " + exObj.Message);

                return Unauthorized(new Response 
                { 
                    ErrorMessage = exObj.Message, 
                    IsSuccess = false 
                });
            }

            return result;
        }

        private string GenerateWedToken(IEnumerable<CompanySignUpInfo> authenticatedUserInfo)
        {

            var securityKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(this._configuration["Jwt:Key"]));

            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                this._configuration["Jwt:Issuer"],
                null,
                expires: DateTime.Now.AddHours(12),
                signingCredentials:credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }


        private void validateLogin(LoginInfo loginInfo)
        {
            if (loginInfo.CompanyCode == null || loginInfo.CompanyCode.Length == 0)
            {
                throw new ArgumentException("Company Code is required and should not be Null or Empty!");
            }

            if(loginInfo.Password == null || loginInfo.Password.Length == 0)
            {
                throw new ArgumentException("Password is required and should not be Null or Empty!");
            }
        }
    }
}
