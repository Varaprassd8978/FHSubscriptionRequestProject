﻿using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces
{
    public interface ISchedulingRepository
    {
        Task<SchedulingModel> CreateNewSchedule(SchedulingModel schedulingData);
        Task<SchedulingModel> UpdateExistingSchedule(SchedulingModel schedulingData);
        Task<List<SchedulingModel>> GetAllSchedules();
        Task<List<SchedulingModel>> GetSchedulesByIds(string CompanyID, string ScheduleID);
        Task<List<SchedulingModel>> SchedulesListByCompanyID(string companyID);
        public Task<bool> DeleteSchedules(string companyID, string scheduleID);
        //Task<SchedulingModel> ReteriveSchduleData(string partitionKey, string rowKey);
    }
}
