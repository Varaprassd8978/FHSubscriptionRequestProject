﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class SchedulingModel : TableEntity
    {
        public SchedulingModel() { }

        public SchedulingModel(
        string scheduleID, string companyId) :
            base(partitionKey: companyId,
                 rowKey: scheduleID )
        {
            this.ScheduleID = scheduleID;
            this.CompanyID = companyId;
        }

        public string ScheduleID { get; set; }
        public string CompanyID { get; set; }
        public DishItems[] DishesItems { get; set; }

        [JsonIgnore]
        public string DishesItem { get; set; }       
        //public string PlanType { get; set; }
        public bool IsBreakfast { get; set; } = false;
        public bool IsLunch { get; set; } = false;
        public bool IsDinner { get; set; } = false;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string PointOfContact { get; set; }

        //[JsonIgnore]
        public DateTime CreatedDate { get; set; }

        //[JsonIgnore]
        public DateTime UpdatedDate { get; set; }
        public DateTime[] ExclusionDates { get; set; }

        [JsonIgnore]
        public string ExclusionDatesValue { get; set; }
        public DayOfWeek[] ExclusionWeeks { get; set; }

        [JsonIgnore]
        public string ExclusionWeeksValue { get; set; }
        public DeliveryTime[] ItemDeliveryTime { get; set; }

        [JsonIgnore]
        public string ItemsDeliveryTime { get; set; }
        public string ExclusionReason { get; set; }            
        public bool IsActive { get; set; }
        //public bool IsDeleted { get; set; }
               
    }

    public class DishItems
    {
        public string DishItemName { get; set; }
        public string Description { get; set; }
        public string DishImageUrl { get; set; }
        public double Cost { get; set; }
        public int NoOfUnits { get; set; }
        public double TaxValue { get; set; }
        public double PackingCharges { get; set; }
        public double DeliveryCharges { get; set; }
        public bool IsDishRequired { get; set; }

        public override string ToString()
        {
            return string.Format(@"{0}, {1}, {2}, {3}, {4}, {5}, {6},{7}",

                this.DishItemName, this.Description, this.Cost, this.NoOfUnits, this.TaxValue, this.PackingCharges,
                this.DeliveryCharges, this.IsDishRequired).ToString();
        }
    }

    public class DeliveryTime
    {
        public string Lunch { get; set; }
        public string Breakfast { get; set; }
        public string Dinner { get; set; }
        public string Snacks { get; set; }
    }
}

//public override string ToString()
//{
//    return string.Format(@"{0}, {1}, {2}, {3}, {4}, {5}, {6},{7},{8},{9},{10},{11},{12},{13},{14}",


//        this.PlanType,
//        this.StartDate,
//        this.EndDate,
//        this.PointOfContact,
//        this.ExclusionDates,
//        this.ExclusionWeeks,
//        this.DeliveryTime,
//        this.ExclusionReason).ToString();
//}