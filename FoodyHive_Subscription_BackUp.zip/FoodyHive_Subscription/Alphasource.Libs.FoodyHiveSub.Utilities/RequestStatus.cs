﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alphasource.Libs.FoodyHiveSub.Utilities
{
    public enum RequestStatus
    {
        Request,
        Approved,
        Rejected,
    }
}
