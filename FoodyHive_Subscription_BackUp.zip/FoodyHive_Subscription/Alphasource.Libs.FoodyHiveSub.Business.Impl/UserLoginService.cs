﻿using Alphasource.Libs.FoodyHiveSub.Business.Interfaces;
using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Business.Impl
{
    public class UserLoginService : IUserLoginService
    {
       private static Dictionary<LoginInfo, IEnumerable<CompanySignUpInfo>> members = default(Dictionary<LoginInfo, IEnumerable<CompanySignUpInfo>>);

        private IUserLoginRepository _userRepo = default;
     
        public UserLoginService(IUserLoginRepository userRepo)
        {          
            this._userRepo = userRepo;            
        }          

        public async Task<IEnumerable< CompanySignUpInfo>> ValidateUserCredentials(LoginInfo loginCredentials)
        {
            var isParameterValid = loginCredentials != default(LoginInfo);
            
            if (!isParameterValid)
                throw new ArgumentException(nameof(loginCredentials));

            var result = await this._userRepo.ValidateUserCredentials(loginCredentials);
          //  var companysListResult = await this._userRepo.GetAllCompanies();
          if(result.Count<CompanySignUpInfo>() != 0)
            {
                members = new Dictionary<LoginInfo, IEnumerable<CompanySignUpInfo>>();
                members.Add(loginCredentials, result);

                var filteredLoginInfo = members.Keys.Where(key => key.CompanyCode.Equals(loginCredentials.CompanyCode)).FirstOrDefault();

                if (filteredLoginInfo == default(LoginInfo))
                {
                    throw new ArgumentException("Invalid Login Info Provided!");
                }

                var isLoginValid = filteredLoginInfo.Password.Equals(loginCredentials.Password);

                if (!isLoginValid)
                {
                    throw new ArgumentException("Invalid Credentials Specified!");
                }

               var autheenticatedUserInfo = members[filteredLoginInfo];

                return autheenticatedUserInfo;
            }
            else
            {
                throw new ArgumentException("Invalid Credentials Specified!");
            }         

          
        }
     
    }
}
