﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class CompanyQuickInfo
    {
        public string CompanyId { get; set; }
        public string CompanyName { get; set; }

        [StringLength(50)]
        public string SubscriberName { get; set; }

        public string EmailId { get; set; }

        public string PhoneNumber { get; set; }
    }
}
