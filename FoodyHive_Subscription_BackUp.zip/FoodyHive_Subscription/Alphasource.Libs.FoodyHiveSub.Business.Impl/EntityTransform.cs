﻿using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Alphasource.Libs.FoodyHiveSub.Business.Impl
{
    public static class EntityTransform
    {

        public static SubscriptionRequest TransformEntity( SubscriptionRequest entityData)
        {
        //    var subscriptionRequestEnity = default(SubscriptionRequest);

        //    if(entityData != default)
        //    {
        //        subscriptionRequestEnity = new SubscriptionRequest(entityData.CompanyName, entityData.RequestId);


        //        subscriptionRequestEnity.CompanyName = entityData.CompanyName;
        //        subscriptionRequestEnity.EmailId = entityData.EmailId;
        //        subscriptionRequestEnity.RequestId = entityData.RequestId;
        //        subscriptionRequestEnity.SubscriberName = entityData.SubscriberName;

        //        subscriptionRequestEnity.DeliveryAddress = (Address)JsonConvert.DeserializeObject(entityData.FullAddress);
        //        subscriptionRequestEnity.FullAddress = entityData.FullAddress;

        //        subscriptionRequestEnity.SubscriptionDate = entityData.SubscriptionDate;

        //        subscriptionRequestEnity.DishPlanDetails = entityData.DishPlanDetails;
        //        subscriptionRequestEnity.DishPlan = (DishPlan[])JsonConvert.DeserializeObject(entityData.DishPlanDetails); 

        //        subscriptionRequestEnity.Plan = entityData.Plan;

        //        subscriptionRequestEnity.DeliverySchedule = (Schedule[])JsonConvert.DeserializeObject(entityData.DeliveryDetails);
        //        subscriptionRequestEnity.DeliveryDetails = entityData.DeliveryDetails;

        //        subscriptionRequestEnity.TotalOrderValue = entityData.TotalOrderValue;
        //        subscriptionRequestEnity.Status = entityData.Status;

        //    }


            return null;
        }
    }
}
