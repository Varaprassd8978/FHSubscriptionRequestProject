﻿using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces
{
    public interface ICompanySignUpRepository
    {
        Task<CompanySignUpInfo> Create(CompanySignUpInfo companyInfo);

        Task<List<CompanySignUpInfo>> GetAllCompaniesList();

        Task<List<CompanySignUpInfo>> GetCompanyDetailsById(string companyId);

        Task<bool> DeleteCompany(string companyName, string companyId);

        Task<bool> UpdateComapnyRoleToAdmin(string companyId, bool IsAdmin);

    }
}
