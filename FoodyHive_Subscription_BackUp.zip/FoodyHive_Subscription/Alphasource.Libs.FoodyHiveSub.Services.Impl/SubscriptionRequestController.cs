﻿using Alphasource.Libs.FoodyHiveSub.Business.Interfaces;
using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Services.Impl
{    
    /// <summary>
    /// SubscriptionRequest API Controller
    /// </summary>
    /// 
    [Route("api/[controller]")]
    [ApiController]
   // [Authorize]
    public class SubscriptionRequestController : ControllerBase
    {
        private ISubscriptionRequestService _subscriptionRequestService = default;
        private string mode = default(string);

        /// <summary>
        /// Primary SubscriptionRequestController Constructor
        /// </summary>
        /// <param name="subscripitonRequestServioce"></param>
        /// 
        public SubscriptionRequestController(ISubscriptionRequestService subscripitonRequestServioce)
        {
            this._subscriptionRequestService = subscripitonRequestServioce;
        }

        /// <summary>
        /// USER - To Add New Subscription Request Order
        /// </summary>
        /// <param name="subscriptionRequest"></param>
        /// <returns></returns>
        /// 
        [Route("Create")]
        [HttpPost]
        public async Task<IActionResult> InsertNewSubscriprtionRequest(SubscriptionRequest subscriptionRequest)
        {
            var validation = subscriptionRequest != default(SubscriptionRequest);
            //   var result = default(ActionResult);

            try
            {
                this.mode = "create";
                 ValidataEntityData(subscriptionRequest);               

                if (!validation)
                {
                    return BadRequest("Inavalid Arguments");
                }
                else
                {
                    var status = await this._subscriptionRequestService.InsertNewSubscriprtionRequest(subscriptionRequest);

                    if (status)
                    {
                        return Ok(new Response { IsSuccess = status, SuccessMessage = "Request Inserted Successfully", data = subscriptionRequest.RequestId });
                    }
                    else
                    {
                        return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }

        }

        /// <summary>
        /// ADMIN - To Update the Subscription Request Status
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="companyId"></param>        
        /// <param name="requestStauts"></param>        
        /// <returns></returns>
        [Route("UpdateRequestStatus/{requestId}/{companyId}/{requestStauts}")]
        [HttpPut]
        public async Task<IActionResult> UpdateSubscriptionRequestStaus(string requestId, string companyId, string requestStauts)
        {
            var validate = !string.IsNullOrWhiteSpace(requestId) ||
                            !string.IsNullOrWhiteSpace(requestStauts);
            if (!validate)
                return BadRequest(new Response { ErrorMessage = "Invalid Arguments", IsSuccess = false });

            try
            {
                if (!(requestStauts.ToLower().Contains("approved")) && !(requestStauts.ToLower().Contains("rejected")))
                {
                    return BadRequest(new Response { ErrorMessage = "Invalid RequestStatus. Request Status should only given as Approved (or) Rejected ", IsSuccess = false });
                }
                else
                {
                    var status = await this._subscriptionRequestService.UpdateSubscriptionRequestStaus(requestId, companyId, requestStauts);

                    if (status)
                    {
                        return Ok(new Response { IsSuccess = status, SuccessMessage = "Subscription Request Status Updated Successfully," });
                    }
                    else
                    {
                        return NotFound(new Response { ErrorMessage = "Unkown Error Occured", IsSuccess = false });
                    }
                }
            }
            catch (Exception ex)
            {
                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }


        /// <summary>
        /// To update the Subscription Request
        /// </summary>
        /// <param name="requestData"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("UpdateRequest")]

        public async Task<IActionResult> UpdateRequest(SubscriptionRequest requestData)
        {
            var validation = requestData != default(SubscriptionRequest);
            //   var result = default(ActionResult);

            try
            {
                this.mode = "update";
                ValidataEntityData(requestData);

                if (!validation)
                {
                    return BadRequest("Inavalid Arguments");
                }
                else
                {
                    var status = await this._subscriptionRequestService.UpdateSubscriptionRequest(requestData);

                    if (status)
                    {
                        return Ok(new Response { IsSuccess = status, SuccessMessage = "Data Update Successfully", data = requestData.RequestId });
                    }
                    else
                    {
                        return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }



        /// <summary>
        /// To Delete the Request Delete
        /// </summary>
        /// <param name="companyId"></param>
        /// <param name="requestId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("DeleteRequest/{companyId}/{requestId}")]
        public async Task<IActionResult> DeleteRequest(string companyId, string requestId)
        {
            var validation = !string.IsNullOrEmpty(companyId) ||
                string.IsNullOrEmpty(requestId);
            //   var result = default(ActionResult);

            try
            {                
                if (!validation)
                {
                    return BadRequest("Inavalid Arguments");
                }
                else
                {
                    var status = await this._subscriptionRequestService.DeleteRequest(companyId, requestId);

                    if (status)
                    {
                        return Ok(new Response { IsSuccess = status, SuccessMessage = "Data Deleted Successfully", data = requestId });
                    }
                    else
                    {
                        return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }










        ///// <summary>
        ///// To Get Subscription Request Data by StartDate and EndDate
        ///// </summary>
        ///// <param name="startDate"></param>
        ///// <param name="endDate"></param>
        ///// <returns></returns>
        ///// 
        //[Route("GetDataByDateFilter/{startDate}/{endDate}")]
        //[HttpGet]
        //public async Task<IActionResult> GetSubsciprionResquestsByDates(DateTime startDate, DateTime endDate)
        //{
        //    try
        //    {
        //        var result = await this._subscriptionRequestService.GetSubsciprionResquestsByDates(startDate, endDate);

        //        if (result != null)
        //        {
        //            return Ok(new Response { IsSuccess = true, SuccessMessage = "Filtered Data", data= result, Count = result.Count() });

        //           // return Ok(result);
        //        }
        //        else
        //        {
        //            return NotFound(new Response { ErrorMessage = "Unkown Error Occured", IsSuccess = false });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
        //    }

        //}



        /// <summary>
        /// To Get All the Subscription Requests List
        /// </summary>
        /// <returns></returns>
        /// 
        [Route("")]
        [HttpGet]
        public async Task<IActionResult> GetAllRequestsList()
        {
            var queryResult = default(IEnumerable<SubscriptionRequest>);
            var result = default(IActionResult);
            try
            {
                queryResult = await _subscriptionRequestService.GetAllRequestsList();
                return Ok(new Response { IsSuccess = true, data = queryResult, SuccessMessage = "Succesful", Count = queryResult.Count() });
               // result = Ok(queryResult);

            }
            catch (Exception ex)
            {
                result = StatusCode(500, new
                {
                    Success = false,
                    Message = ex.Message
                });
            }

            return result;
        }

        /// <summary>
        /// USER/ADMIN - To Get All Subscription Requests List By CompanyId { ADMIN - Can See All Request Data }, { USER - Can See his Individual Request Data Only }
        /// </summary>
        /// <param name="companyId"></param>
        /// <returns></returns>
        /// 
        [Route("GetAllRequestsListBy/{companyId}")]
        [HttpGet]
        public async Task<IActionResult> GetAllRequestsListByCompanyId(string companyId)
        {
            try
            {
                var result = await this._subscriptionRequestService.GetAllRequestsListByCompanyId(companyId);

                if (result != null)
                {
                    return Ok(new Response { IsSuccess = true, data = result, SuccessMessage = "Succesful", Count= result.Count() });
                }
                else
                {
                    return NotFound(new Response { ErrorMessage = "Unkown Error Occured", IsSuccess = false });
                }
            }
            catch (Exception ex)
            {
                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }

        /// <summary>
        /// To Get Request Dat By RequestId,CompanyId
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="companyId"></param>
        /// <returns></returns>
        /// 
        [Route("GetRequestListBy/{requestId}/{companyId}")]
        [HttpGet]
        public async Task<IActionResult> GetRequestListById(string requestId, string companyId)
        {
            try
            {
                var result = await this._subscriptionRequestService.GetRequestListByIds(requestId, companyId);

                if (result != null)
                {
                    return Ok(new Response { IsSuccess = true, data = result, SuccessMessage = "Succesful", Count = result.Count() });
                }
                else
                {
                    return NotFound(new Response { ErrorMessage = "Unkown Error Occured", IsSuccess = false });
                }
            }
            catch (Exception ex)
            {
                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }


        /// <summary>
        /// To Get Subscription Request List By CompanyId
        /// </summary>
        /// <param name="requestId"></param>
        /// <returns></returns>
        /// 
        [Route("GetRequestListBy/{requestId}")]
        [HttpGet]
        public async Task<IActionResult> GetRequestListById(string requestId)
        {
            try
            {
                var result = await this._subscriptionRequestService.GetRequestListByRequestId(requestId);

                if (result != null)
                {
                    return Ok(new Response { IsSuccess = true, data = result, SuccessMessage = "Succesful", Count = result.Count() });
                }
                else
                {
                    return NotFound(new Response { ErrorMessage = "Unkown Error Occured", IsSuccess = false });
                }
            }
            catch (Exception ex)
            {
                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }







        /// <summary>
        /// USER/ADMIN - To Get Subscription Requests Data By Filter 
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        /// 
        [Route("GetSubscriptionRequestByFilter")]
        [HttpPost]
        public async Task<IActionResult> GetSubscriptionRequestByFilter(RequestDataByFilter filter) 
        {
            try
            {
                var result = await this._subscriptionRequestService.
                    GetSubscriptionRequestByFilter(filter.companyId, filter.status, filter.search, filter.StartDate, filter.EndDate, filter.pagesize, filter.pageindex);

                if (result != null)
                {
                    return Ok(new Response { IsSuccess = true, data = result, SuccessMessage = "Successfully",Count= result.RequestsList.Count });
                }
                else
                {
                    return NotFound(new Response { ErrorMessage = "Unkown Error Occured", IsSuccess = false });
                }
            }
            catch (Exception ex)
            {
                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }

        }




           
        

        /// <summary>
        ///  USER - To make Cancellation Request to cancel the Subscription Request Order
        /// </summary>
        /// <param name="cancellationRequest"></param>
        /// <returns></returns>
        [Route("CancellationRequest")]
        [HttpPost]
        public async Task<IActionResult> SubscriptionCancellationRequest(CancellationRequest cancellationRequest)
        {
            //var validate = !string.IsNullOrWhiteSpace(requestId) || !string.IsNullOrWhiteSpace(requestCancelReason);
            var validate = cancellationRequest != default(CancellationRequest);           

            if (!validate)
                return BadRequest(new Response { ErrorMessage = "Invalid Arguments!", IsSuccess = false });

            try
            {
                   validateCancellationRequestModel(cancellationRequest);         
                
                    var status = await this._subscriptionRequestService.SubscriptionCancellationRequest(cancellationRequest);

                    if (status)
                    {
                        return Ok(new Response { IsSuccess = status,data = cancellationRequest,  SuccessMessage = "Subscription Cancellation Request Status Upated Successfully" });
                    }
                    else
                    {                        
                        return NotFound(new Response { ErrorMessage = "Unkown Error Occured!", IsSuccess = false });
                    }             

            }
            catch (Exception ex)
            {
                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }

        /// <summary>
        /// ADMIN - To update the cancellation Request Response by Approved or Rejected 
        /// </summary>
        /// <param name="cancellationResponse"></param>
        /// <returns></returns>
        /// 
        [Route("CancellationResponse")]
        [HttpPut]
        public async Task<IActionResult> UpdateSubscriptionCancellationRequest(CancellationResponse cancellationResponse)
        {         

            var validate = cancellationResponse != default(CancellationResponse);
            if (!validate)
                return BadRequest(new Response { ErrorMessage = "Invalid Arguments!", IsSuccess = false });

            try
            {
                validateCancellationResponseModel(cancellationResponse);

                if (!(cancellationResponse.ResponseCancellationStatus.ToLower().Contains("cancellation approved")) && !(cancellationResponse.ResponseCancellationStatus.ToLower().Contains("cancellation rejected")))
                {
                    return BadRequest(new Response { ErrorMessage = "Invalid RequestStatus. Response Status should only given as Cancellation Approved or Cancellation Rejected!", IsSuccess = false });
                }
                else
                {
                    var status = await this._subscriptionRequestService.UpdateSubscriptionCancellationResponse(cancellationResponse);

                    if (status)
                    {
                        return Ok(new Response { IsSuccess = status, data= cancellationResponse, SuccessMessage = "Subscription Request Cancellation Response Status Updated Successfully," });
                    }
                    else
                    {                        
                        return NotFound(new Response { ErrorMessage = "Unkown Error Occured", IsSuccess = false });
                    }
                }
            }
            catch (Exception ex)
            {
                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }

        private static readonly string INVALID_ADDRESS_ENTERY = "The Address field is required (or) Address coantains NULL or Empty values";
        private static readonly string INVALID_STATUS = "The Status field is required (or) Status might be given as NULL!";
        private static readonly string INVALID_POSTAL_CODE_FORMAT = "Invalid Postal_Code Format is Enterd ! Postal_Code should be of length of 6";
        private static readonly string INVALID_TOTAL_ORDER_VALUE = "Invalid Total_Order_Value is Entered (or) should not be Less Than Zero!";


        private void ValidataEntityData(SubscriptionRequest entityModelData)
        {
            if (!entityModelData.CompanyId.Contains("CMPNY"))
            {
                throw new ArgumentException("Invalid Company Id");
            }
            if (entityModelData.CompanyId.Length == 0)
            {
                throw new ArgumentException("CompanyID is required and cannot be null or empty!");
            }

            if (entityModelData.CompanyId.Length > 19 || entityModelData.CompanyId.Length < 19) 
            {
                throw new ArgumentException("Invalid CompanyID is specified!");
            }

            if (this.mode == "create")
            {
                if (entityModelData.SubscriptionDate < System.DateTime.Today)
                {
                    throw new ArgumentException("Subscription Date Field should not be less than Present/Current Date!");
                }
            }

            if(entityModelData.DeliveryAddresses.Length == 0)
            {
                throw new ArgumentException(INVALID_ADDRESS_ENTERY);
            }

            var NumberRegx = @"^[0-9]*$";

            foreach (var item in entityModelData.DeliveryAddresses) 
            {
                if (item.AddressLine1.Length == 0)
                {
                    throw new ArgumentException("Address Line1 field is required and Should not be Empty!");
                }
                else if (item.City.Length == 0)
                {
                    throw new ArgumentException("City field is required and Should not be Empty!");
                }
                else if (item.State.Length == 0)
                {
                    throw new ArgumentException("State field is required and Should not be Empty!");
                }
                else if (item.Country.Length == 0)
                {
                    throw new ArgumentException("Country field is required and Should not be Empty!");
                }
                else if (item.PostalCode.Length == 0)
                {
                    throw new ArgumentException("Postal Code field is required and Should not be Empty!");                    
                }
                else
                {
                  
                }

                var validPostalCode = Regex.IsMatch(item.PostalCode, NumberRegx, RegexOptions.IgnoreCase);

                if (!validPostalCode)
                {
                    throw new ArgumentException("Postal Code Field should contains only numbers!");
                }

                if (item.PostalCode.Length > 6 || item.PostalCode.Length < 6)
                {
                    throw new ArgumentException(INVALID_POSTAL_CODE_FORMAT);                  
                }

            }

            if (entityModelData.SchedullingInfo.Length == 0)
            {
                throw new ArgumentException("Schedulling Info Should contain atleast one schedule info item!");
            }



            if (entityModelData.TotalOrderValue < 0)
            {
                throw new ArgumentException(INVALID_TOTAL_ORDER_VALUE);                
            }

            if (entityModelData.Status == null || entityModelData.Status.Length == 0)
            {
                throw new ArgumentException(INVALID_STATUS);                
            }

            if(this.mode == "create")
            if (entityModelData.Status.ToLower() != "request")
            {
                throw new ArgumentException("The Status should contain -- Request keyword Only!");
            }

        }     
        

        private void validateCancellationRequestModel(CancellationRequest entityData)
        {
            if (!entityData.companyId.Contains("CMPNY"))
            {
                throw new ArgumentException("Invalid Company Id");
            }

            if (!entityData.requestId.Contains("REQFH"))
            {
                throw new ArgumentException("Invalid Request Id");
            }

            if (entityData.companyId.Length == 0)
            {
                throw new ArgumentException("CompanyID is required and cannot be null or empty!");
            }

            if (entityData.companyId.Length > 19 || entityData.companyId.Length < 19)
            {
                throw new ArgumentException("Invalid CompanyID is specified!");
            }

            if (entityData.requestId.Length == 0)
            {
                throw new ArgumentException("RequestID is required and cannot be null or empty!");
            }

            if (entityData.requestId.Length > 19 || entityData.requestId.Length < 19)
            {
                throw new ArgumentException("Invalid RequestID is specified!");
            }

            if (entityData.RequestCancelDate < System.DateTime.Today)
            {
                throw new ArgumentException("Request Cancellation Date Field should not be less than Present/Current Date!");
            }
        }

        private void validateCancellationResponseModel(CancellationResponse entityData)
        {
            if (!entityData.companyId.Contains("CMPNY"))
            {
                throw new ArgumentException("Invalid Company Id");
            }

            if (!entityData.requestId.Contains("REQFH"))
            {
                throw new ArgumentException("Invalid Request Id");
            }

            if (entityData.companyId.Length == 0)
            {
                throw new ArgumentException("CompanyID is required and cannot be null or empty!");
            }

            if (entityData.companyId.Length > 19 || entityData.companyId.Length < 19)
            {
                throw new ArgumentException("Invalid CompanyID is specified!");
            }

            if (entityData.requestId.Length == 0)
            {
                throw new ArgumentException("RequestID is required and cannot be null or empty!");
            }

            if (entityData.requestId.Length > 19 || entityData.requestId.Length < 19)
            {
                throw new ArgumentException("Invalid RequestID is specified!");
            }

            if (entityData.ResponseCancellationDate < System.DateTime.Today)
            {
                throw new ArgumentException("Request Cancellation Date Field should not be less than Present/Current Date!");
            }
        }

    }
}
