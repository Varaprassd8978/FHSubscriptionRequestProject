using System;
using Xunit;

namespace Alphasource.Libs.FoodyHiveSub.Business.Impl.Tests
{
    public class SubReqeustBusinessTest
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
