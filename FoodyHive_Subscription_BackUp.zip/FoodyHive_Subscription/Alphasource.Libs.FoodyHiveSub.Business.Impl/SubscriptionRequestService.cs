﻿using Alphasource.Libs.FoodyHiveSub.Business.Interfaces;
using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace Alphasource.Libs.FoodyHiveSub.Business.Impl
{
    /// <summary>
    /// Subscription Request Service
    /// </summary>
    /// 
    public class SubscriptionRequestService : ISubscriptionRequestService
    {
        private ISubscriptionRequestRepository _subscriptionRequestRepo = default;

        /// <summary>
        /// Subscription Request Service Primary constructor depends on the ISubscriptionRequestRepository
        /// </summary>
        /// <param name="subscriptionRequestRepository"></param>
        /// 
        public SubscriptionRequestService(ISubscriptionRequestRepository subscriptionRequestRepository )
        {
            this._subscriptionRequestRepo = subscriptionRequestRepository;
        }


        /// <summary>
        /// Subscription Request Service to get all the Subscription Request Data List
        /// </summary>
        /// <returns></returns>
        /// 
        public async Task<IEnumerable<SubscriptionRequest>> GetAllRequestsList()
        {
            //var subscriptionList = default(List<SubscriptionRequest>);
            //var entityResult = await _subscriptionRequestRepo.GetAllSubscribersList();

            //subscriptionList = entityResult.Select(entityData => entityData.
            //)
            // return _subscriptionRequestRepo.GetAllSubscribersList();

            var requestData = await _subscriptionRequestRepo.GetAllRequestsList();
            
            var requestResult = requestData.Where(x => x.IsActive == true);
            if (requestResult == null)
            {
                throw new Exception("No Data Found");
            }

            return requestResult;
        }


        /// <summary>
        /// Subscription Request Service to Insert new Subscripotion Request Data
        /// </summary>
        /// <param name="subscriptionRequest"></param>
        /// <returns></returns>
        /// 
        public Task<bool> InsertNewSubscriprtionRequest(SubscriptionRequest subscriptionRequest)
        {

            //foreach(var item in subscriptionRequest.DeliverySchedule) 
            //{
            //    item.PointOfContact = subscriptionRequest.SubscriberName;
            //}

            subscriptionRequest.FullDeliveryAddress = JsonConvert.SerializeObject(subscriptionRequest.DeliveryAddresses);
            subscriptionRequest.SchedullingDetails = JsonConvert.SerializeObject(subscriptionRequest.SchedullingInfo);            

            return _subscriptionRequestRepo.InsertNewSubscriprtionRequest(subscriptionRequest);
        }


        ///// <summary>
        ///// Subscription Request Service to Update the complete Subscription Request data
        ///// </summary>
        ///// <param name="subscription"></param>
        ///// <returns></returns>
        ///// 
        //public Task<bool> UpdateSubscriptionRequest(SubscriptionRequest subscription)
        //{

        //    //subscription.FullAddress = JsonConvert.SerializeObject(subscription.DeliveryAddress);
        //    //subscription.DishDetails = JsonConvert.SerializeObject(subscription.DishItems);
        //    //subscription.DeliveryScheduleDetails = JsonConvert.SerializeObject(subscription.DeliverySchedule);

        //    return _subscriptionRequestRepo.UpdateSubscriptionRequest(subscription);
        //}


        /// <summary>
        /// Service to upadte Subscription Request Status using RequestID
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="requestStauts"></param>
        /// <returns></returns>
        /// 
        public Task<bool> UpdateSubscriptionRequestStaus(string requestId,string companyId, string requestStauts)
        {
            return _subscriptionRequestRepo.UpdateSubscriptionRequestStaus(requestId,companyId, requestStauts);
        }

        /// <summary>
        /// Service to get Subscription Request Data based on the Start Date and End Date
        /// </summary>
        /// <param name="subscriptionStartDate"></param>
        /// <param name="subscriptionEndDate"></param>
        /// <returns></returns>
        /// 
        public Task<IEnumerable<SubscriptionRequest>> GetSubsciprionResquestsByDates(DateTime subscriptionStartDate, DateTime subscriptionEndDate)
        {
            //return _subscriptionRequestRepo.GetSubsciprionResquestsByDates(subscriptionStartDate, subscriptionEndDate);
            throw new NotImplementedException();
        }


        /// <summary>
        /// Service to get Subscription Request Data based on the company, subscriber, Email or PhoneNumber searchStrings
        /// </summary>
        /// <param name="searchString"></param>
        /// <returns></returns>
        /// 
        public Task<IEnumerable<SubscriptionRequest>> GetSubscriptionRequestsBySearch(string companyId, string searchString)
        {
            return _subscriptionRequestRepo.GetSubscriptionRequestsBySearch(companyId,searchString);
        }


        ///// <summary>
        ///// Service to get Subscription Request Data based on the DishName Search
        ///// </summary>
        ///// <param name="dishItemName"></param>
        ///// <returns></returns>
        //public Task<IEnumerable<SubscriptionRequest>> GetSubscriptionRequestsByDishItem(string dishItemName)
        //{
        //    return _subscriptionRequestRepo.GetSubscriptionRequestsByDishItem(dishItemName);
        //}

        public Task<bool> SubscriptionCancellationRequest(CancellationRequest cancellationRequest)
        {
            return _subscriptionRequestRepo.SubscriptionCancellationRequest(cancellationRequest);
        }

        public Task<bool> UpdateSubscriptionCancellationResponse(CancellationResponse cancellationResponse)
        {
           return _subscriptionRequestRepo.UpdateSubscriptionCancellationResponse(cancellationResponse);
        }

        public async Task<IEnumerable<SubscriptionRequest>> GetAllRequestsListByCompanyId(string companyId)
        {
            var requestData = await _subscriptionRequestRepo.GetAllRequestsListByCompanyId(companyId);

            var requestResult = requestData.Where(x => x.IsActive == true);
            if (requestResult == null)
            {
                throw new Exception("No Data Found with the given CompanyId");
            }
            return requestResult;
         //   return _subscriptionRequestRepo.GetAllRequestsListByCompanyId(companyId);
        }

        public Task<RequestDataList> GetSubscriptionRequestByFilter(string companyId, string status, string search, DateTime? startDate, DateTime? endDate, int pagesize, int pageindex)
        {
            return _subscriptionRequestRepo.GetSubscriptionRequestByFilter(companyId, status, search,startDate,endDate, pagesize, pageindex);
        }

        public async Task<IEnumerable<SubscriptionRequest>> GetRequestListByRequestId(string requestId)
        {
            var requestData = await _subscriptionRequestRepo.GetRequestListByRequestId(requestId);

            var requestResult = requestData.Where(x => x.IsActive == true);
            if(requestResult == null)
            {
                throw new Exception("No Data Found with the given requestId");
            }

            return requestResult;
           // return _subscriptionRequestRepo.GetRequestListByRequestId(requestId);
        }

        public async Task<IEnumerable<SubscriptionRequest>> GetRequestListByIds(string requestId, string companyId)
        {
            var requestData = await _subscriptionRequestRepo.GetRequestListByIds(requestId, companyId);

            var requestResult = requestData.Where(x => x.IsActive == true);
            if (requestResult == null)
            {
                throw new Exception("No Data Found with the given RequestId & CompanyId");
            }
            return requestResult;
           // return _subscriptionRequestRepo.GetRequestListByIds(requestId, companyId);
        }

        public Task<bool> UpdateSubscriptionRequest(SubscriptionRequest subscriptionData) 
        {
            subscriptionData.FullDeliveryAddress = JsonConvert.SerializeObject(subscriptionData.DeliveryAddresses);
            subscriptionData.SchedullingDetails = JsonConvert.SerializeObject(subscriptionData.SchedullingInfo);
            return _subscriptionRequestRepo.UpdateSubscriptionRequest(subscriptionData);
        }

        public Task<bool> DeleteRequest(string companyId, string requestId) 
        {
            return _subscriptionRequestRepo.DeleteRequest(companyId, requestId);
        }

    }
}
