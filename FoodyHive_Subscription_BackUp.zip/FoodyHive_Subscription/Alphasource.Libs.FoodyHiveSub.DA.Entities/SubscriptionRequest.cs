﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Text.Json.Serialization;

namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class SubscriptionRequest : TableEntity
    {
        public SubscriptionRequest() { }


        public SubscriptionRequest(string companyId, string requestId) :
            base(partitionKey: companyId,
                 rowKey: requestId)
        {
            this.CompanyId = companyId;
            this.RequestId = requestId;
        }

        public string RequestId { get; set; }

        //[JsonIgnore]
        public string CompanyId { get; set; }

      
        public string CompanyName { get; set; }

       
        [StringLength(50)]
        public string SubscriberName { get; set; }

        
        public string EmailId { get; set; }

        
        public string PhoneNumber { get; set; }

        public Address[] DeliveryAddresses { get; set; }

        [JsonIgnore]
        public string FullDeliveryAddress { get; set; }


        public DateTime SubscriptionDate { get; set; } = new DateTime(
             DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);

        [JsonIgnore]
        public DateTime ModifiedDate { get; set; } = new DateTime(
     DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);

        public SchedulingModel[] SchedullingInfo { get; set; }

        [JsonIgnore]
        public string SchedullingDetails { get; set; }

        //public string Plan { get; set; }

        //public Schedule[] DeliverySchedule { get; set; }

        //[JsonIgnore]
        //public string DeliveryDetails { get; set; }

        [JsonIgnore]
        public DateTime RequestCancelDate { get; set; } = new DateTime(
             DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);
        [JsonIgnore]
        public string RequestCancelStatus { get; set; }
        [JsonIgnore]
        public string RequestCancelReason { get; set; }
        [JsonIgnore]
        public DateTime ResponseCancellationDate { get; set; } = new DateTime(
             DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);
        [JsonIgnore]
        public string ResponseCancellationStatus { get; set; } 
        [JsonIgnore]
        public string ResponseCancellationReason { get; set; }       
        

        public string PromoCode { get; set; }

        public string Notes { get; set; }

        public int TotalOrderValue { get; set; }

        public string Status { get; set; }

        [JsonIgnore]
        public string EmailFlag { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }        
    }

    public class Schedule
    {
        public DateTime Date { get; set; } = new DateTime(
            DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);
        public string TimeRange { get; set; }
        public string PointOfContact { get; set; }
        public override string ToString()
        {
            return string.Format(@"{0}, {1}, {2}",

                this.Date, this.TimeRange, this.PointOfContact).ToString();
        }
    }

    public class CancellationRequest {     
        
        public string requestId { get; set; }

        public string companyId { get; set; }

        public DateTime RequestCancelDate { get; set; }

        public string RequestCancelStatus { get; set; }

        public string RequestCancelReason { get; set; }
    }

    public class CancellationResponse{

        public string requestId { get; set; }

        public string companyId { get; set; }

        public DateTime ResponseCancellationDate { get; set; }

        public string ResponseCancellationStatus { get; set; }

        public string ResponseCancellationReason { get; set; }

    }
}
