﻿using System;

namespace Alphasource.Libs.FoodyHiveSub.DA.Impl
{
    public class SubscriptionContext
    {
    }
}
