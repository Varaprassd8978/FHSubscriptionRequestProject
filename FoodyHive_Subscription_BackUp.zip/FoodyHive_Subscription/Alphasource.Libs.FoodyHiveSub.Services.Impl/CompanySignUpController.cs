﻿using Alphasource.Libs.FoodyHiveSub.Business.Interfaces;
using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Services.Impl
{

    /// <summary>
    /// Company Registration API Controller
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]

    public class CompanySignUpController : ControllerBase
    {
        private ICompanySignUpService _companySignUpService = default;

        private static readonly string INVALID_EMAILID_FORMAT = "Invalid Email Adderess Format is Entered! (ex: abcd1234@gmail.com)";
        private static readonly string INVALID_PHONE_NUMBER_FORMAT = "Invalid Phone Number Format is Entered! Phone Number should contains Ten digits(ex:9988776655)";
        private static readonly string INVALID_POSTAL_CODE_FORMAT = "Invalid Postal_Code Format is Enterd ! Postal_Code should be of length of 6";
        private static readonly string INVALID_COMPANY_NAME = "The Company Name field is required (or) Company Name might be given as NULL or Empty.";
        private static readonly string INVALID_EMAILID = "The Email ID field is required (or) Email ID might be given as NULL or Empty.";
        private static readonly string INVALID_PHONE_NUMBER = "The Phone Number field is required (or) Phone Number might be given as NULL or Empty.";
        private static readonly string INVALID_SUBSCRIBER_NAME = "The Subscriber Name field is required (or) Subscriber Name might be given as NULL or Empty.";



        /// <summary>
        /// Primary Constructor of Comapny SignUp Controller
        /// </summary>
        /// <param name="companySignUpService"></param>
        /// 
        public CompanySignUpController(ICompanySignUpService companySignUpService)
        {
            _companySignUpService = companySignUpService;
        }

        /// <summary>
        /// Register the new Company details
        /// </summary>
        /// <param name="companyInfo"></param>
        /// <returns></returns>
        /// 
        [HttpPost]
        [Route("RegisterNewCompany")]
        public async Task<ActionResult> Create(CompanySignUpInfo companyInfo)
        {
            var validate = companyInfo != default(CompanySignUpInfo);
            var result = default(CompanySignUpInfo);
            try
            {
                ValidateEntityData(companyInfo);

                if (!validate)
                {
                    return BadRequest("Invalid Entity model");
                }
                else
                {
                    result = await this._companySignUpService.Create(companyInfo);

                    if (result != null)
                    {
                        //return Ok(result);
                        return Ok(new Response { IsSuccess = true, SuccessMessage = "Data Inserted Successfully", data = result });
                    }
                    else
                    {
                        return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }

        /// <summary>
        /// To Update the Company User Role To Admin
        /// </summary>
        /// <param name="companyId"></param>
        /// <param name="IsAdmin"></param>
        /// <returns></returns>
        [Route("UpdateUserRole/{companyId}/{IsAdmin}")]
        [HttpPut]
        public async Task<ActionResult> UpdateComapnyRoleToAdmin(string companyId, bool IsAdmin)
        {
            var validate = !string.IsNullOrEmpty(companyId);
            var status = default(bool);
            try
            {
                if (!validate)
                {
                    return BadRequest("Invalid Arguments");
                }
                else
                {
                    status = await this._companySignUpService.UpdateComapnyRoleToAdmin(companyId, IsAdmin);

                    if (status == true)
                    {
                        //return Ok(result);
                        return Ok(new Response { IsSuccess = status, SuccessMessage = "User Role Is Updated Successfully",data= companyId });
                    }
                    else
                    {
                        return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }



        /// <summary>
        /// Get All Registered Companies Data
        /// </summary>
        /// <returns></returns>
        /// 
        [Route("")]
        [HttpGet]
        public async Task<ActionResult> GetAllCompaniesList()
        {
            var queryResult = default(IEnumerable<CompanySignUpInfo>);
            //var result = default(IActionResult);
            try
            {
                queryResult = await _companySignUpService.GetAllCompaniesList();


                if (queryResult != null)
                {
                    return Ok(new Response { IsSuccess = true, SuccessMessage = "Success", data = queryResult });
                }
                else
                {
                    return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                }


            }
            catch (Exception ex)
            {

                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });

            }
        }


        ///// <summary>
        ///// Deletes the Companies Information
        ///// </summary>
        ///// <param name="companyName"></param>
        ///// <param name="companyId"></param>
        ///// <returns></returns>
        ///// 
        //[Route("delete/{companyName}/{companyId}")]
        //[HttpDelete]
        //public async Task<ActionResult> DeleteCompany(string companyName, string companyId)
        //{
        //    var validate = !string.IsNullOrEmpty(companyName) ||
        //                    !string.IsNullOrEmpty(companyId);
        //    var result = default(bool);

        //    try
        //    {           

        //        if (!validate)
        //        {
        //            return BadRequest("Invalid Entery");
        //        }
        //        else
        //        {
        //            result = await this._companySignUpService.DeleteCompany(companyName,companyId);

        //            if (result == true)
        //            {
        //                //return Ok(result);
        //                return Ok(new Response { IsSuccess = true, SuccessMessage = "Data Inserted SUccessfully", data = result });
        //            }
        //            else
        //            {
        //                return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new Response { ErrorMessage = ex.Message, IsSuccess = false });
        //    }

        //}


        private void ValidateEntityData(CompanySignUpInfo validateModel)
        {
            if (validateModel.CompanyName == null || validateModel.CompanyName.Length == 0)
            {
                throw new ArgumentException(INVALID_COMPANY_NAME);               
            }

            if (validateModel.SubscriberName == null || validateModel.SubscriberName.Length == 0)
            {
                throw new ArgumentException(INVALID_SUBSCRIBER_NAME);               
            }
            if (validateModel.SubscriberName.Length < 6)
            {
                throw new ArgumentException("Invalid Subscriber Name. Name should contain at 6 characters!");
            }

            if (validateModel.EmailId == null || validateModel.EmailId.Length == 0)
            {
                throw new ArgumentException(INVALID_EMAILID);               
            }


            // string RegEx = @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z";

            string RegEx = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
            var validEmailIdFormat = (Regex.IsMatch(validateModel.EmailId, RegEx, RegexOptions.IgnoreCase));

            if (!validEmailIdFormat)
            {
                throw new ArgumentException(INVALID_EMAILID_FORMAT);                
            }

            if (validateModel.PhoneNumber == null || validateModel.PhoneNumber.Length == 0)
            {
                throw new ArgumentException(INVALID_PHONE_NUMBER);               
            }


            var NumberRegx = @"^[0-9]*$";
            var validPhoneNo = (Regex.IsMatch(validateModel.PhoneNumber, NumberRegx, RegexOptions.IgnoreCase));
            if (!validPhoneNo)
            {
                throw new ArgumentException("Phone Number Should contain only numbers");
            }

            var validPhoneNumberFormat = !(validateModel.PhoneNumber.Length < 10 || validateModel.PhoneNumber.Length > 12);

            if (!validPhoneNumberFormat)
            {
                throw new ArgumentException(INVALID_PHONE_NUMBER_FORMAT);              
            }


            if (validateModel.CAddress.AddressLine1.Length == 0)
            {
                throw new ArgumentException("Address Line1 field is required and Should not be Empty!");
            }
            else if (validateModel.CAddress.City.Length == 0)
            {
                throw new ArgumentException("City field is required and Should not be Empty!");
            }
            else if (validateModel.CAddress.State.Length == 0)
            {
                throw new ArgumentException("State field is required and Should not be Empty!");
            }
            else if (validateModel.CAddress.Country.Length == 0)
            {
                throw new ArgumentException("Country field is required and Should not be Empty!");
            }
            else if (validateModel.CAddress.PostalCode.Length == 0)
            {
                throw new ArgumentException("Postal Code field is required and Should not be Empty!");
            }
            else
            {
                // throw new ArgumentException(INVALID_ADDRESS_ENTERY);
            }

            var validPostalCode = Regex.IsMatch(validateModel.CAddress.PostalCode, NumberRegx, RegexOptions.IgnoreCase);

            if (!validPostalCode)
            {
                throw new ArgumentException("Postal Code Field should contains only numbers");
            }


            if (validateModel.CAddress.PostalCode.Length > 6 || validateModel.CAddress.PostalCode.Length < 6)
            {
                throw new ArgumentException(INVALID_POSTAL_CODE_FORMAT);                
            }
        }
    }
}
