﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class LoginInfo
    {
        public string CompanyCode { get; set; }
        public string Password { get; set; }

        //public override string ToString()
        //{
        //    return string.Format(@"{0},{1}", this.CompanyCode, this,Password);
        //}

    }
}
