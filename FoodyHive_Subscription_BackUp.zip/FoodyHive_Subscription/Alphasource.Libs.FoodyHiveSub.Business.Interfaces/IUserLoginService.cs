﻿using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Business.Interfaces
{
    public interface IUserLoginService
    {
        Task<IEnumerable<CompanySignUpInfo>> ValidateUserCredentials(LoginInfo loginCredentials);
    }    
}
