﻿using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces
{
    public interface ISubscriptionRequestRepository
    {
        //Corporate Users Part
        Task<bool> InsertNewSubscriprtionRequest(SubscriptionRequest subscriptionRequest);        
      
        Task<IEnumerable<SubscriptionRequest>> GetSubsciprionResquestsByDates(string companyId,DateTime subscriptionStartDate, DateTime subscriptionEndDate);

        Task<IEnumerable<SubscriptionRequest>> GetSubscriptionRequestsBySearch(string companyId, string searchString);

        //  Task<IEnumerable<SubscriptionRequest>> GetSubscriptionRequestsByDishItem(string dishItemName);
        Task<bool> UpdateSubscriptionRequest(SubscriptionRequest subscriptionData);

        Task<bool> DeleteRequest(string companyId, string requestId);

        Task<bool> SubscriptionCancellationRequest(CancellationRequest cancellationRequest);


        //Display Data based on Admin & User roles
        Task<IEnumerable<SubscriptionRequest>> GetAllRequestsList();
        Task<IEnumerable<SubscriptionRequest>> GetAllRequestsListByCompanyId(string CompanyId);
        Task<IEnumerable<SubscriptionRequest>> GetRequestListByRequestId(string RequestId);
        Task<IEnumerable<SubscriptionRequest>> GetRequestListByIds(string RequestId, string CompanyId);

        //Admin Part
        Task<bool> UpdateSubscriptionCancellationResponse(CancellationResponse cancellationResponse);
        Task<bool> UpdateSubscriptionRequestStaus(string requestId,string companyId, string requestStauts);

        //Gets the Subscription Data Based on the Status,StartDate,EndDate, Search String, pagination
       
        Task<RequestDataList> GetSubscriptionRequestByFilter(string companyId, string status, string search, DateTime? startDate, DateTime? endDate, int pagesize, int pageindex);

    }
}
