﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class DishPlan
    {
        public string CompanyId { get;}
        public string DishItemName { get; set; }
        public string Description { get; set; }
        public double Cost { get; set; }
        public int NoOfUnits { get; set; }
        public double TaxValue { get; set; }
        public double PackingCharges { get; set; }
        public double DeliveryCharges { get; set; }
        public string PlanType { get; set; }

        public bool IsBreakfast { get; set; } = false;
        public bool IsLunch { get; set; } = false;
        public bool IsDinner { get; set; } = false;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string PointOfContact { get; set; }
        public DateTime[] ExclusionDates { get; set; }
        public string DeliveryTime { get; set; }
        public string ExclusionReason { get; set; }

        public override string ToString()
        {
            return string.Format(@"{0}, {1}, {2}, {3}, {4}, {5}, {6},{7},{8},{9},{10},{11},{12},{13}",

                this.DishItemName, this.Description, this.Cost, this.NoOfUnits, this.TaxValue, this.PackingCharges,
                this.DeliveryCharges,
                this.PlanType,
                this.StartDate,
                this.EndDate,
                this.PointOfContact,
                this.ExclusionDates,
                this.DeliveryTime,
                this.ExclusionReason).ToString();
        }
    }
}
