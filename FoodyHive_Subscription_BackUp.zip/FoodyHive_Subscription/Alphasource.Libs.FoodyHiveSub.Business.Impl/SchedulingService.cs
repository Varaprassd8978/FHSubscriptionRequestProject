﻿using Alphasource.Libs.FoodyHiveSub.Business.Interfaces;
using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Business.Impl
{
    public class SchedulingService : ISchedulingService
    {

        private ISchedulingRepository _schedulingRepository = default;


        public SchedulingService(ISchedulingRepository schedulingRepository)
        {
            this._schedulingRepository = schedulingRepository;
        }
        public async Task<SchedulingModel> CreateNewSchedule(SchedulingModel schedulingData)
        {
            
            schedulingData.DishesItem = JsonConvert.SerializeObject(schedulingData.DishesItems);
            schedulingData.ItemsDeliveryTime = JsonConvert.SerializeObject(schedulingData.ItemDeliveryTime);
            schedulingData.ExclusionDatesValue = JsonConvert.SerializeObject(schedulingData.ExclusionDates);
            schedulingData.ExclusionWeeksValue = JsonConvert.SerializeObject(schedulingData.ExclusionWeeks);

            return await this._schedulingRepository.CreateNewSchedule(schedulingData);
        }    
       

        public async Task<List<SchedulingModel>> GetSchedulesByIds(string CompanyID, string ScheduleID)
        {
            return await this._schedulingRepository.GetSchedulesByIds(CompanyID, ScheduleID);
        }

        public Task<SchedulingModel> UpdateExistingSchedule(SchedulingModel schedulingData)
        {
            schedulingData.DishesItem = JsonConvert.SerializeObject(schedulingData.DishesItems);
            schedulingData.ItemsDeliveryTime = JsonConvert.SerializeObject(schedulingData.ItemDeliveryTime);
            schedulingData.ExclusionDatesValue = JsonConvert.SerializeObject(schedulingData.ExclusionDates);
            schedulingData.ExclusionWeeksValue = JsonConvert.SerializeObject(schedulingData.ExclusionWeeks);

            return this._schedulingRepository.UpdateExistingSchedule(schedulingData);
        }

        public Task<bool> DeleteSchedules(string companyID, string scheduleID)
        {
            return this._schedulingRepository.DeleteSchedules(companyID, scheduleID);
        }

        public async Task<List<SchedulingModel>> GetAllSchedules()
        {
            return await this._schedulingRepository.GetAllSchedules();
        }

        public async Task<List<SchedulingModel>> SchedulesListByCompanyID(string companyID)
        {
            return await this._schedulingRepository.SchedulesListByCompanyID(companyID);
        }
    }
}
