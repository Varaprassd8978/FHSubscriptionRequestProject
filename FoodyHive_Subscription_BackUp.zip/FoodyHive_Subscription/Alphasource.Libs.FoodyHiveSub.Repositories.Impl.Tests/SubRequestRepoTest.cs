using System;
using Xunit;

namespace Alphasource.Libs.FoodyHiveSub.Repositories.Impl.Tests
{
    public class SubRequestRepoTest
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
