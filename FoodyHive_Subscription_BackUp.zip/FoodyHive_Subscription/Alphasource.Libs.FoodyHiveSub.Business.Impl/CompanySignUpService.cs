﻿using Alphasource.Libs.FoodyHiveSub.Business.Interfaces;
using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Business.Impl
{
    public class CompanySignUpService : ICompanySignUpService
    {
        private ICompanySignUpRepository _companySignUpRepo = default;
        public CompanySignUpService(ICompanySignUpRepository companySignUp)
        {
            this._companySignUpRepo = companySignUp;
        }

        public Task<CompanySignUpInfo> Create(CompanySignUpInfo companyInfo)
        {
            companyInfo.FullAddress = JsonConvert.SerializeObject(companyInfo.CAddress);
            return this._companySignUpRepo.Create(companyInfo);
        }

        public Task<bool> DeleteCompany(string companyName, string companyId)
        {
            return this._companySignUpRepo.DeleteCompany(companyName, companyId);
        }

        public Task<List<CompanySignUpInfo>> GetAllCompaniesList()
        {
            return this._companySignUpRepo.GetAllCompaniesList();
        }

        public Task<bool> UpdateComapnyRoleToAdmin(string companyId, bool IsAdmin)
        {
            return this._companySignUpRepo.UpdateComapnyRoleToAdmin(companyId, IsAdmin);
        }
    }
}
