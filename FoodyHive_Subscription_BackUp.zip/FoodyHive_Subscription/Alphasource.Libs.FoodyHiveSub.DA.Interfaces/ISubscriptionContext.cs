﻿using System;

namespace Alphasource.Libs.FoodyHiveSub.DA.Interfaces
{
    public interface ISubscriptionContext
    {
    }
}
