﻿namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    //public class Schedule
    //{
    //    public string Date { get; set; }
    //    public string Time { get; set; }
    //    public string PointOfContact { get; set; }
    //    public override string ToString()
    //    {
    //        return string.Format(@"{0}, {1}, {2}",

    //            this.Date, this.Time, this.PointOfContact);
    //    }
    //}
}