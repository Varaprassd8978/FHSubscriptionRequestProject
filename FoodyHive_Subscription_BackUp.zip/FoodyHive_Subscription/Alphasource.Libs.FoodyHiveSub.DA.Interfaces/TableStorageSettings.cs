﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alphasource.Libs.FoodyHiveSub.DA.Interfaces
{
    public class TableStorageSettings
    {
        public string ConnectionString { get; set; }

        public string TableName { get; set; }

    }
}
