﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class RequestDataByFilter
    {    
        public string companyId { get; set; } 
        public string status { get; set; }
        public string search { get; set; }
        public DateTime? StartDate { get; set; } 
        public DateTime? EndDate { get; set; } 
        public int pagesize { get; set; } 
        public int pageindex { get; set; }
        //   public string requestId { get; set; } 
    }
}
