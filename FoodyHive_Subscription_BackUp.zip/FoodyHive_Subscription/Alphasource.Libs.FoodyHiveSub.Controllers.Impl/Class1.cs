﻿using System;

namespace Alphasource.Libs.FoodyHiveSub.Controllers.Impl
{
    public class Class1
    {
    }
}
