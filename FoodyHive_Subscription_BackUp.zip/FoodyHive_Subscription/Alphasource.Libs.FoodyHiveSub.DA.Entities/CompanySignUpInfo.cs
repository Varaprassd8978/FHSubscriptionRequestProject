﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Text.Json.Serialization;

namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class CompanySignUpInfo : TableEntity
    {

        public CompanySignUpInfo() { }


        public CompanySignUpInfo(string companyName, string companyId) :
            base(partitionKey: companyName,
                 rowKey: companyId)
        {
            this.CompanyName = companyName;
            this.CompanyId = companyId;
        }

        public string CompanyId { get; set; }
        public string CompanyName { get; set; }

        [JsonIgnore]
        public string CompanyCode { get; set; }

        [JsonIgnore]
        //[PasswordPropertyText]
        public string Password { get; set; }

        [StringLength(50)]
        public string SubscriberName { get; set; }
        //public string Role { get; set; }

        public string EmailId { get; set; }

        public string PhoneNumber { get; set; }

        public Address CAddress { get; set; }

        [JsonIgnore]
        public string FullAddress { get; set; }

        public Boolean IsAdmin { get; set; }

        public string EmailFlag { get; set; }

        //public Boolean IsActive { get; set; }

        //public string CreatedBy { get; set; }

        //public DateTime CreatedOn { get; set; }

        //public string ModifiedBy { get; set; }

        //public DateTime ModifiedOn { get; set; }
    }
}
