﻿using Alphasource.Libs.FoodyHiveSub.Business.Interfaces;
using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alphasource.Libs.FoodyHiveSub.Services.Impl
{
    

    /// <summary>
    /// Dish Schdeulling API Controller
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class SchedulingController : ControllerBase
    {
        private ISchedulingService _schedulingService = default;
        private string mode = default;
       // private static readonly string INVALID_TOTAL_ORDER_VALUE = "Invalid Total_Order_Value is Entered (or) should not be Less Than Zero!";

        /// <summary>
        /// Primary Constructor of the Dish Schdeulling
        /// </summary>
        /// <param name="schedulingService"></param>
        /// 
        public SchedulingController(ISchedulingService schedulingService)
        {
            this._schedulingService = schedulingService;
        }

        /// <summary>
        /// To Added New Scheduling Data
        /// </summary>
        /// <param name="schedulingData"></param>
        /// <returns></returns>
        /// 

        [HttpPost]
        [Route("AddNewSchedule")]
        public async Task<ActionResult> AddNewSchedule(SchedulingModel schedulingData)
        {
            var validate = schedulingData != default(SchedulingModel);
            var result = default(SchedulingModel);
            try
            {
                this.mode = "create";
                ValidataEntityData(schedulingData);
                if (!validate)
                {
                    return BadRequest("Invalid Entity Model Data Entry!");
                }
                else
                {
                    result = await this._schedulingService.CreateNewSchedule(schedulingData);

                    if (result != null)
                    {
                        return Ok(new Response { IsSuccess = true, SuccessMessage = "Scheduling Data Inserted Successfully", data = result });
                    }
                    else
                    {
                        return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                    }
                }
            }

            catch (Exception expObj)
            {
                return BadRequest(new Response { ErrorMessage = expObj.Message, IsSuccess = false });
            }
        }


        
        /// <summary>
        /// To Gets All the Schedulling Dish Data List
        /// </summary>
        /// <returns></returns>
        /// 
        [Route("")]
        [HttpGet]
        public async Task<IActionResult> GetAllSchedules()
        {
            var queryResult = default(IEnumerable<SchedulingModel>);
            //var result = default(IActionResult);
            try
            {
                queryResult = await _schedulingService.GetAllSchedules();


                if (queryResult != null)
                {
                    return Ok(new Response { IsSuccess = true, SuccessMessage = "Success", data = queryResult, Count = queryResult.Count() });
                }
                else
                {
                    return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                }


            }
            catch (Exception ex)
            {
                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }


        /// <summary>
        /// To Get the Schedulling Data List based on the CompanyId and ScheduleId
        /// </summary>
        /// <param name="companyId"></param>
        /// <param name="scheduleId"></param>
        /// <returns></returns>
        /// 
        [Route("GetScheduleDataById/{companyId}/{scheduleId}")]
        [HttpGet]
        public async Task<IActionResult> GetSchedulesDataByIds(string companyId, string scheduleId)
        {
            var queryResult = default(IEnumerable<SchedulingModel>);
            //var result = default(IActionResult);
            try
            {
                queryResult = await _schedulingService.GetSchedulesByIds(companyId, scheduleId);


                if (queryResult != null)
                {
                    return Ok(new Response { IsSuccess = true, SuccessMessage = "Success", data = queryResult, Count=queryResult.Count() });
                }
                else
                {
                    return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                }


            }
            catch (Exception ex)
            {
                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }


        /// <summary>
        /// To Get Schedules By CompanyID
        /// </summary>
        /// <param name="companyId"></param>
        /// <returns></returns>
        /// 
        [Route("GetSchedulesByID/{companyId}")]
        [HttpGet]
        public async Task<IActionResult> GetSchedulesByCompanyId(string companyId)
        {
            var queryResult = default(IList<SchedulingModel>);
            //var result = default(IActionResult);
            try
            {
                queryResult = await _schedulingService.SchedulesListByCompanyID(companyId);


                if (queryResult != null)
                {
                    return Ok(new Response { IsSuccess = true, SuccessMessage = "Success", data = queryResult,Count= queryResult.Count });
                }
                else
                {
                    return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                }


            }
            catch (Exception ex)
            {
                return NotFound(new Response { ErrorMessage = ex.Message, IsSuccess = false });
            }
        }


        /// <summary>
        /// To Update the Existing Schedule Data
        /// </summary>
        /// <param name="existingScheduleData"></param>
        /// <returns></returns>
        /// 
        [Route("UpdateSchedule")]
        [HttpPut]
        public async Task<ActionResult> UpdateExistingSchedule(SchedulingModel existingScheduleData)
        {
            var validate = existingScheduleData != default(SchedulingModel);
            var result = default(SchedulingModel);
            try
            {
                this.mode ="update";
                ValidataEntityData(existingScheduleData);
                if (!validate)
                {
                    return BadRequest("Invalid Entity Model Data Entry!");
                }
                else
                {
                    result = await this._schedulingService.UpdateExistingSchedule(existingScheduleData);

                    if (result != null)
                    {
                        return Ok(new Response { IsSuccess = true, SuccessMessage = "Scheduling Data Updated Successfully", data = result });
                    }
                    else
                    {
                        return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                    }
                }
            }

            catch (Exception expObj)
            {
                return BadRequest(new Response { ErrorMessage = expObj.Message, IsSuccess = false });
            }
        }


        /// <summary>
        /// To Delete the Schedule Data Permanent
        /// </summary>
        /// <param name="companyId"></param>
        /// <param name="scheduleID"></param>
        /// <returns></returns>
        [Route("DeleteSchedule/{companyId}/{scheduleID}")]
        [HttpDelete]
        public async Task<ActionResult> DeleteSchedule(string companyId, string scheduleID)
        {
            var validation = !string.IsNullOrEmpty(scheduleID) &&
               !string.IsNullOrEmpty(companyId);

            var result = default(ActionResult);
     
                try
                {
                    if (!validation)
                        result = BadRequest("INVALID_ARGUMENTS!.");

                    var status = await this._schedulingService.DeleteSchedules(companyId, scheduleID);

                    if (status)
                    {
                        return Ok(new Response { IsSuccess = status, SuccessMessage = "Schedule Deleted Successfully", data = status });
                    }
                    else
                    {
                        return NotFound(new Response { ErrorMessage = "Unkonwn Error Occured", IsSuccess = false });
                    }
                }
                catch (Exception expObj)
                {
                    return BadRequest(new Response { ErrorMessage = expObj.Message, IsSuccess = false });
                }
            
        }



        private void ValidataEntityData(SchedulingModel entityModelData)
        {
            if (entityModelData.CompanyID == null || entityModelData.CompanyID.Length == 0)
            {
                throw new ArgumentException("CompanyId should not be null!");
            }

            if (!entityModelData.CompanyID.Contains("CMPNY"))
            {
                throw new ArgumentException("Invalid Company Id");
            }

            if(entityModelData.CompanyID.Length>19 || entityModelData.CompanyID.Length < 19)
            {
                throw new ArgumentException("Invalid Company Id");
            }
            //if (this.mode != "update")
            //{
                if (entityModelData.StartDate <= DateTime.Today)
                {
                    throw new ArgumentException("Start Date Field should be greater than Present/Current Date!");
                }
            //}
             
            if (entityModelData.EndDate < entityModelData.StartDate)
            {
                throw new ArgumentException("End Date Field should not be less than Start Date! ");
            }

            if(entityModelData.PointOfContact == null || entityModelData.PointOfContact.Length == 0)
            {
                throw new ArgumentException("Point of Contact should not be null!");
            }           

            if(entityModelData.CreatedDate < DateTime.Today)
            {
                throw new ArgumentException("Created Date Should not be less than the Present Date ");
               //     (or)  (or) Created Date Should not be greated than Schedule End Date!"); 
            }
            //else if(entityModelData.CreatedDate < entityModelData.StartDate)
            //{
            //    throw new ArgumentException("Created Date Should not be less than the Schedule Start Date");
            //}
            //else if(entityModelData.CreatedDate > entityModelData.EndDate)
            //{
            //    throw new ArgumentException("Created Date Should not be less than the Schedule Start Date");
            //}



            //if (mode == "update")
            //{
            //    if (entityModelData.UpdatedDate > entityModelData.EndDate || entityModelData.UpdatedDate < entityModelData.StartDate)
            //    {
            //        throw new ArgumentException("Updated Date Should not be less than the Schedule Start Date (or) Updated Date Should not be greated than Schedule End Date!");
            //    }
            //}

            if (entityModelData.DishesItems.Length == 0)
            {
                throw new ArgumentException("Dish Items Should contain atleast one item!");
            }

            foreach (var item in entityModelData.DishesItems)
            {
                if (item.DishItemName == null || item.DishItemName.Length == 0)
                {
                    throw new ArgumentException("Dish Item Name field is required and Should not be Empty!");

                }
                else if (item.Description == null || item.Description.Length == 0)
                {
                    throw new ArgumentException("Dish Description field is required and Should not be Empty!");
                }
                else if (item.Cost < 0)
                {
                    throw new ArgumentException("Dish Item Cost Should not be less than zero!");
                }
                else if (item.NoOfUnits < 0)
                {
                    throw new ArgumentException("Dish Quantity Should not less than zero!");
                }
                else if (item.PackingCharges < 0)
                {
                    throw new ArgumentException("Dish PackingCharges Should not less than zero!");
                }
                else if (item.TaxValue < 0)
                {
                    throw new ArgumentException("Dish TaxValue Should not less than zero!");
                }
                else if (item.DeliveryCharges < 0)
                {
                    throw new ArgumentException("Dish DeliveryCharges Should not less than zero!");
                }
                else { }
            }


            foreach (var item in entityModelData.ItemDeliveryTime)
            {
                if (item.Lunch.Length == 0 || item.Lunch == null)
                {
                    throw new ArgumentException("Item Delivery Lunch Time Range is required and should not be empty!");
                }

                else if (item.Breakfast.Length == 0 || item.Breakfast == null)
                {
                    throw new ArgumentException("Item Delivery Breakfast Time Range is required and should not be empty!");
                }

                else if (item.Dinner.Length == 0 || item.Dinner == null)
                {
                    throw new ArgumentException("Item Delivery Dinner Time Range is required and should not be empty!");
                }

                else if (item.Snacks.Length == 0 || item.Snacks == null)
                {
                    throw new ArgumentException("Item Delivery Snacks Time Range is required and should not be empty!");
                }
                else { }
            }


            foreach(var item in entityModelData.ExclusionDates)
            {
                if (item < DateTime.Today)
                {
                    throw new ArgumentException("Exclusion Date should not be less than Current/Present Date!");
                }

                if (item < entityModelData.StartDate)
                {
                    throw new ArgumentException("Exclusion Date should not be less than Start Date!");
                }
                if (item > entityModelData.EndDate)
                {
                    throw new ArgumentException("Exclusion Date should not be greated than End Date!");
                }

            }




        }







    }
    }
