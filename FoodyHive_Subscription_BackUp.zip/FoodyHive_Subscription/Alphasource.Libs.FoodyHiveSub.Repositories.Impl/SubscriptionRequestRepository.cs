﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.DA.Interfaces;
using Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces;
using Alphasource.Libs.FoodyHiveSub.Utilities;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;

namespace Alphasource.Libs.FoodyHiveSub.Repositories.Impl
{
    /// <summary>
    /// Subscription Request Repository Class
    /// </summary>
    /// 
    public class SubscriptionRequestRepository : ISubscriptionRequestRepository
    {

        //private ICompanySignUpRepository _companySignUpRepository = default;

        private const string INVALID_TABLE_STORAGE_SETTINGS = "Invalid SubscriptionRequest Table Storage Settings Specified!";
        private const int MAX_ITEMS_TO_FETCH = 5000;
        private TableStorageSettings tableStorageSettings = default;
        private CloudStorageAccount cloudStorageAccount = default;
        private CloudTableClient cloudTableClient = default;
        private CloudTable cloudTable = default;
        
        private CompanySignUpRepository objCompRepo = default;
        private SchedulingRepository objScheduleRepo = default;


        /// <summary>
        /// Subscription Request Repository Primary Constructor depends on the Table Storage Settings
        /// </summary>
        /// <param name="tableStorageSettings"></param>
        /// 
        public SubscriptionRequestRepository(TableStorageSettings tableStorageSettings)
        {
            var validateConnection = tableStorageSettings != default &&
                !string.IsNullOrEmpty(tableStorageSettings.ConnectionString) &&
                !string.IsNullOrEmpty(tableStorageSettings.TableName);

            if (!validateConnection)
            {
                throw new ArgumentException(INVALID_TABLE_STORAGE_SETTINGS);
            }

            this.tableStorageSettings = tableStorageSettings;
            this.cloudStorageAccount = CloudStorageAccount.Parse(this.tableStorageSettings.ConnectionString);
            this.cloudTableClient = this.cloudStorageAccount.CreateCloudTableClient();
            this.cloudTable = this.cloudTableClient.GetTableReference(this.tableStorageSettings.TableName);
            this.objCompRepo = new CompanySignUpRepository(tableStorageSettings);
            this.objScheduleRepo = new SchedulingRepository(tableStorageSettings);

            CreateNewTable(cloudTable);

        }


        /// <summary>
        /// Create the New Azure Table Storage in the Azure Storage Account if Not Exists
        /// </summary>
        /// <param name="table"></param>
        /// 
        public async static void CreateNewTable(CloudTable table)
        {
            if (!await table.CreateIfNotExistsAsync())
            {
                Console.WriteLine("Table already exists");
                return;
            }
            //Console.WriteLine("table {0} Create", table.Name);
        }


        /// <summary>
        /// Inserts New Subscription Request and return the true status
        /// </summary>
        /// <param name="subscriptionRequestEntity"></param>
        /// <returns></returns>
        /// 
        public async Task<bool> InsertNewSubscriprtionRequest(SubscriptionRequest subscriptionRequestEntity)
        {

            var status = default(bool);
            var result = default(SubscriptionRequest);

            // Creates the RequestId
            #region
            string date = DateTime.Now.ToString("ddMMyyyyHHmmss");

            string finalStr = "REQFH" + date;

            subscriptionRequestEntity.RequestId = finalStr;

            subscriptionRequestEntity.PartitionKey = subscriptionRequestEntity.CompanyId;

            subscriptionRequestEntity.RowKey = subscriptionRequestEntity.RequestId;

            subscriptionRequestEntity.ETag = new Random().Next(1, 10000000).ToString();

            subscriptionRequestEntity.SubscriptionDate = DateTime.Now.Date;
            subscriptionRequestEntity.ModifiedDate = new DateTime(
                 DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);

            subscriptionRequestEntity.RequestCancelStatus = null;
            subscriptionRequestEntity.RequestCancelReason = null;
            subscriptionRequestEntity.RequestCancelDate = new DateTime(
                 DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);

            subscriptionRequestEntity.ResponseCancellationReason = null;
            subscriptionRequestEntity.ResponseCancellationStatus = null;
            subscriptionRequestEntity.RequestCancelDate= new DateTime(
                 DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);

            subscriptionRequestEntity.Status = "Request";
            subscriptionRequestEntity.EmailFlag = "N";
            subscriptionRequestEntity.IsActive = true;
            subscriptionRequestEntity.IsDeleted = false;


            //To check the Schedule Data is Existing with the Given Schedule information
            foreach (var item in subscriptionRequestEntity.SchedullingInfo)
            {
               var IsScheduleData = this.objScheduleRepo.GetSchedulesByIds(item.CompanyID, item.ScheduleID);

                if(item.CompanyID != subscriptionRequestEntity.CompanyId)
                {
                    throw new ArgumentException("The Schedule CompanyID and the Request CompanyId both should be the same!");
                }

                if(IsScheduleData.Result.Count == 0)
                {
                    throw new ArgumentException("No Data Found with given scheduleID and CompanyID" + item.ScheduleID +"and "+ item.CompanyID);
                }
                else
                {
                    var scheduleInfo = JsonConvert.SerializeObject(item);
                    Console.WriteLine(scheduleInfo);
                }
            }
            #endregion


            //Gets data based on the CompanyId
            #region
            var companyDataById = objCompRepo.GetCompanyDetailsById(subscriptionRequestEntity.CompanyId);

            if (companyDataById.Result.Count == 0)
            {
                throw new ArgumentException("No Data Found with the given Compnay ID " + subscriptionRequestEntity.CompanyId);
            }

            foreach(var data in companyDataById.Result)
            {
                subscriptionRequestEntity.CompanyName = data.CompanyName;
                subscriptionRequestEntity.SubscriberName = data.SubscriberName;
                subscriptionRequestEntity.EmailId = data.EmailId;
                subscriptionRequestEntity.PhoneNumber = data.PhoneNumber;
            }

            #endregion



            var validation = subscriptionRequestEntity != default &&
                  !string.IsNullOrEmpty(subscriptionRequestEntity.CompanyId) &&
                !string.IsNullOrEmpty(subscriptionRequestEntity.RequestId);

            if (!validation)
                throw new ArgumentException("Invalid subscription Reuqest Entity");            

            var tableOperation = TableOperation.Insert(subscriptionRequestEntity);
            var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);


            //deleting the schedule data from schedule table

            result = (SubscriptionRequest)tableResult.Result;
            foreach (var item in result.SchedullingInfo)
            {
                this.deleteSchedule(item.CompanyID, item.ScheduleID);
            }
            
            var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };

            status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);

            return status;
        }



        private async void deleteSchedule(string comapanyId, string scheduleId)
        {         

          var result = await this.objScheduleRepo.DeleteSchedules(comapanyId,scheduleId);
            if(result == true)
            {
                Console.WriteLine("Schedule Record is deleted");
                Console.WriteLine(result);
            }
            else
            {
                Console.WriteLine("Schedule Record is not deleted");
                Console.WriteLine(result);
            }          

        }

        /// <summary>
        /// To Update the Subscription Request Data (Current We are not Using)
        /// </summary>
        /// <param name="subscriptionData"></param>
        /// <returns></returns>
        /// 
        public async Task<bool> UpdateSubscriptionRequest(SubscriptionRequest subscriptionData)
        {
            var successCodeStatus = default(bool);
            var validation = subscriptionData != default &&
                !string.IsNullOrEmpty(subscriptionData.CompanyId) &&
                !string.IsNullOrEmpty(subscriptionData.RequestId);

            if (!validation)
                throw new ArgumentException("Invalid subscription request data");

            // var existingData = this.ReteriveRequestData(subscriptionData.CompanyId, subscriptionData.RequestId);
            var existingData = await this.GetRequestListByIds(subscriptionData.RequestId, subscriptionData.CompanyId);

            if(existingData.Count() == 0)
            {
                successCodeStatus = false;
                throw new ArgumentException("No Data Found with given RequestId and CompnayId");
            }
            foreach (var data in existingData)
            {
                if (data.IsDeleted != true)
                {

                    if (subscriptionData.RequestId != data.RowKey && subscriptionData.CompanyId != data.PartitionKey)
                    {
                        throw new Exception("please check the  given RequestID and COmpanyID");
                    }
                    
                    if (existingData != default)
                        {
                        if (data.Status.ToLower().Equals("approved"))
                        {
                            successCodeStatus = false;
                            throw new ApplicationException("Request Order is Already Approved. Can't be updated!");
                        }
                        else if (data.Status.ToLower().Equals("rejected"))
                        {
                            successCodeStatus = false;
                            throw new ApplicationException("Request Order is Already Rejected. Can't be updated!");
                        }
                        //else if (data.ResponseCancellationStatus != null) 
                        //{
                        //    if(data.ResponseCancellationStatus.ToLower().Contains("cancellation approved"))
                        //    {
                        //        successCodeStatus = false;
                        //        throw new ApplicationException("cancellation Request Response is Already Approved. Can't be updated!");
                        //    }
                        //    else if(data.ResponseCancellationStatus.ToLower().Contains("cancellation approved")) 
                        //    {
                        //        successCodeStatus = false;
                        //        throw new ApplicationException("cancellation Request Response is Already Rejected. Can't be updated!");
                        //    }
                        //}
                            //To check the Request CompanyID and Schedule CompanyID matches or not.
                            foreach (var item in subscriptionData.SchedullingInfo)
                            {
                                //var IsScheduleData = this.objScheduleRepo.GetSchedulesByIds(item.CompanyID, item.ScheduleID);

                                if (item.CompanyID != subscriptionData.CompanyId)
                                {
                                    throw new ArgumentException("The Schedule CompanyID and the Request CompanyId both should be the same!");
                                }
                            }
                        }

                        //Setting the default and existing values to following fields ETag, RoeKEy, PartationKey, SubscritpionDate,ModifiedDate

                        #region
                        if (string.IsNullOrEmpty(subscriptionData.ETag))
                            subscriptionData.ETag = "*";

                    //subscriptionData.RowKey = data.RowKey;
                    //subscriptionData.PartitionKey = data.PartitionKey;

                    subscriptionData.SubscriptionDate = data.SubscriptionDate;
                        subscriptionData.ModifiedDate = DateTime.Now;

                        subscriptionData.RequestCancelStatus = null;
                        subscriptionData.RequestCancelReason = null;
                        subscriptionData.RequestCancelDate = new DateTime(
                             DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);

                        subscriptionData.ResponseCancellationReason = null;
                        subscriptionData.ResponseCancellationStatus = null;
                        subscriptionData.RequestCancelDate = new DateTime(
                             DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);


                        subscriptionData.EmailFlag = "N";
                        subscriptionData.IsActive = true;
                        subscriptionData.IsDeleted = false;
                        #endregion

                        var tableOperation = TableOperation.Replace(subscriptionData);
                        var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
                        var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };

                        successCodeStatus = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);                        
                   
                }
                else
                {
                    throw new ApplicationException("No Data Found.Data already deleted.");
                }
            }
            return successCodeStatus;
        }


        /// <summary>
        /// Updates the Subscription Request Status to the Approved or Rejected
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="requestStauts"></param>
        /// <returns></returns>
        /// 
        public async Task<bool> UpdateSubscriptionRequestStaus(string requestId,string companyId, string requestStauts)
        {
            var status = default(bool);
            var validation = !string.IsNullOrEmpty(requestId) || !string.IsNullOrEmpty(requestStauts);


            if (!validation)
                throw new ArgumentException("Invalid Argument");

            var IsAdmin= await this.IsUserAdminOrNot(companyId);

            if (IsAdmin == true)
            {

                //var existingData = await this.GetSubscriptionRequestDataById(companyId, requestId);
                var existingData = await this.GetRequestListByRequestId(requestId);

                var IsRequestApprovedOrRejected = default(string);
                var IsDeleted = default(bool);

                foreach (var item in existingData)
                {
                    IsRequestApprovedOrRejected = item.Status;
                    IsDeleted = item.IsDeleted;
                }

                if (IsDeleted != true)
                {
                    //if (!(IsRequestApprovedOrRejected.ToLower().Equals("approved") || IsRequestApprovedOrRejected.ToLower().Equals("rejected")))
                    //{
                        var tableOperation = default(dynamic);
                        if (existingData.Count() != 0)
                        {
                            foreach (var item in existingData)
                            {
                                item.Status = requestStauts;
                                tableOperation = TableOperation.Replace(item);
                            }
                        }
                        else
                        {
                            throw new ArgumentException("No Data Found for the given RequestID " + requestId + " check the requestId");
                        }
                        var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
                        var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };

                        status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);

                        return status;
                    //}
                    //else
                    //{
                    //    throw new Exception("Your Request might be already Approved (or) Rejected. Please contact the Operational Team!");
                    //}
                }
                else
                {
                    throw new Exception("No Data Found. Data already Deleted");
                }
            }
            else
            {
                throw new Exception("Your are not a Authorized User to perform this action.Since, User is not a admin.");
            }               


        }

        /// <summary>
        /// returns the Subscription Request List of Data based on the RequestID and CompanyID
        /// </summary>
        /// <param name="companyId"></param>
        /// <param name="requestId"></param>
        /// <returns></returns>
        public async Task<List<SubscriptionRequest>> GetSubscriptionRequestDataById(string companyId, string requestId)
        {
            var validation = !string.IsNullOrEmpty(requestId) ||
                             !string.IsNullOrEmpty(companyId) ;
            var subscriotionDataEntity = new List<SubscriptionRequest>();

            if (!validation)
                throw new ArgumentException("Invalid Arguments");


            var companyDataById = objCompRepo.GetCompanyDetailsById(companyId);         
            
            if(companyDataById.Result.Count == 0)
            {
                throw new ArgumentException("No Data Found with the given Compnay ID " + companyId);
            }
            string compnyID = null;
            foreach (var data in companyDataById.Result)
            {
                compnyID = data.CompanyId;                
            }

            if (companyId == compnyID)
            {
                var queryCondition1 = TableQuery.GenerateFilterCondition("RequestId", QueryComparisons.Equal, requestId);
                var queryCondition2 = TableQuery.GenerateFilterCondition("CompanyId", QueryComparisons.Equal, companyId);

                var combinedFilters = TableQuery.CombineFilters(queryCondition1, TableOperators.And, queryCondition2);

                var query = new TableQuery<SubscriptionRequest>().Where(combinedFilters).Take(MAX_ITEMS_TO_FETCH);

                var Token = default(TableContinuationToken);

                do
                {
                    var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SubscriptionRequest>(query, Token);
                    if(queryResult.Results.Count == 0)
                    {
                        throw new Exception("No Data Found");
                    }
                    subscriotionDataEntity.AddRange(queryResult.Results);
                    Token = queryResult.ContinuationToken;
                } while (Token != null && query != null);

                return subscriotionDataEntity;
            }
            else
            {
                throw new ArgumentException("No Data Found with the given Compnay ID " + companyId);
            }

        }
        

        /// <summary>
        /// Rseturns the Subscritpion Request Data based on the Given Start Date and End Date
        /// </summary>
        /// <param name="subscriptionStartDate"></param>
        /// <param name="subscriptionEndDate"></param>
        /// <returns></returns>
        /// 
        public async Task<IEnumerable<SubscriptionRequest>> GetSubsciprionResquestsByDates(string companyId, DateTime subscriptionStartDate, DateTime subscriptionEndDate)
        {
            var validate = subscriptionStartDate != default(DateTime) || subscriptionEndDate != default(DateTime);

            if (!validate)
                throw new ArgumentException("Invalid Arguments");

            var IsUserAdmin = await this.IsUserAdminOrNot(companyId);

            var IdQueryFilter = TableQuery.GenerateFilterCondition("CompanyId", QueryComparisons.Equal, companyId);
            var subscriptionStartDateCondition = TableQuery.GenerateFilterConditionForDate("SubscriptionDate", QueryComparisons.GreaterThanOrEqual, subscriptionStartDate);

            var combinedFilters = default(string);

            if (subscriptionEndDate != default)
            {
                var subscriptionEndDateCondition = TableQuery.GenerateFilterConditionForDate("SubscriptionDate", QueryComparisons.LessThanOrEqual, subscriptionEndDate);

                if (!IsUserAdmin)
                {
                    combinedFilters = TableQuery.CombineFilters(IdQueryFilter, TableOperators.And, TableQuery.CombineFilters(subscriptionStartDateCondition, TableOperators.And, subscriptionEndDateCondition));                  
                }
                else
                {
                    combinedFilters = TableQuery.CombineFilters(subscriptionStartDateCondition, TableOperators.And, subscriptionEndDateCondition);
                }              

            }
            else
            {
                combinedFilters = subscriptionStartDateCondition;
            }

            var query = new TableQuery<SubscriptionRequest>()
               .Where(combinedFilters)
               .Take(MAX_ITEMS_TO_FETCH);



            var Token = default(TableContinuationToken);
            var subscriotionDataEntity = new List<SubscriptionRequest>();

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SubscriptionRequest>(query, Token);

                //if (queryResult.Results.Count == 0)
                //{
                //    throw new Exception("No Data Found");
                //}

                subscriotionDataEntity.Capacity += queryResult.Results.Count;

                foreach (var item in queryResult.Results)
                {
                    if (item.FullDeliveryAddress != null || item.SchedullingDetails != null)
                    {
                        var addressReult = JsonConvert.DeserializeObject<Address[]>(item.FullDeliveryAddress);
                        item.DeliveryAddresses = addressReult;

                        var schedules = JsonConvert.DeserializeObject<SchedulingModel[]>(item.SchedullingDetails);
                        item.SchedullingInfo = schedules;
                    }                 

                }
                subscriotionDataEntity.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;

                if (Token != null && query.TakeCount.HasValue)
                {
                    var itemsToLoad = query.TakeCount.Value - subscriotionDataEntity.Count;

                    query = itemsToLoad > 0 ? query.Take(itemsToLoad) : null;
                }

            } while (Token != null && query != null);


            return subscriotionDataEntity;
        }


        /// <summary>
        /// To Get the Subscription Request Data based on search by (CompanyName, SubscriberName, EmailId or PhoneNumber as input to searchString) 
        /// </summary>
        /// <param name="searchString"></param>
        /// <returns></returns>
        /// 
        public async Task<IEnumerable<SubscriptionRequest>> GetSubscriptionRequestsBySearch(string companyId, string searchString)
        {
            var validate = !string.IsNullOrEmpty(searchString) || searchString == null;

            if (!validate)
                throw new ArgumentException("Invalid Search String Arguments");

            var IsUserAdmin = await this.IsUserAdminOrNot(companyId);

            var combinedFilters = default(string);

            var RegEx = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
            var phoneNoRegx = @"^[0-9]*$";

            if (!IsUserAdmin)
            {
                var queryCondition = TableQuery.GenerateFilterCondition("CompanyId", QueryComparisons.Equal, companyId);
                if (Regex.IsMatch(searchString, RegEx, RegexOptions.IgnoreCase))
                {
                    var emailQuery = TableQuery.GenerateFilterCondition("EmailId", QueryComparisons.Equal, searchString);
                    combinedFilters = TableQuery.CombineFilters(queryCondition, TableOperators.And, emailQuery);
                }
                else if (Regex.IsMatch(searchString, phoneNoRegx, RegexOptions.IgnoreCase))
                {
                    var numberQuery = TableQuery.GenerateFilterCondition("PhoneNumber", QueryComparisons.Equal, searchString);
                    combinedFilters = TableQuery.CombineFilters(queryCondition, TableOperators.And, numberQuery);
                }
                else
                {
                    var companyNameQuery = TableQuery.GenerateFilterCondition("CompanyName", QueryComparisons.Equal, searchString);
                    var subscriberNameQuery = TableQuery.GenerateFilterCondition("SubscriberName", QueryComparisons.Equal, searchString);
                  //  combinedFilters = TableQuery.CombineFilters(queryCondition, TableOperators.And, companyNameQuery);

                    combinedFilters = TableQuery.CombineFilters(queryCondition,
                        TableOperators.And,(TableQuery.CombineFilters(companyNameQuery,
                        TableOperators.Or, subscriberNameQuery)));
                }
                //else
                //{
                //    var subscriberNameQuery = TableQuery.GenerateFilterCondition("SubscriberName", QueryComparisons.Equal, searchString);
                //    combinedFilters = TableQuery.CombineFilters(queryCondition, TableOperators.And, subscriberNameQuery);
                //}

            }
            else
            {
                if (Regex.IsMatch(searchString, RegEx, RegexOptions.IgnoreCase))
                {
                    var emailQuery = TableQuery.GenerateFilterCondition("EmailId", QueryComparisons.Equal, searchString);
                }
                else if (Regex.IsMatch(searchString, phoneNoRegx, RegexOptions.IgnoreCase))
                {
                    var numberQuery = TableQuery.GenerateFilterCondition("PhoneNumber", QueryComparisons.Equal, searchString);
                }
                else
                {
                    var companyNameQuery = TableQuery.GenerateFilterCondition("CompanyName", QueryComparisons.Equal, searchString);
                    var subscriberNameQuery = TableQuery.GenerateFilterCondition("SubscriberName", QueryComparisons.Equal, searchString);
                    combinedFilters = TableQuery.CombineFilters(companyNameQuery, TableOperators.Or, subscriberNameQuery);

                    //combinedFilters = TableQuery.CombineFilters(TableQuery.CombineFilters(queryCondition,TableOperators.And, companyNameQuery),
                    //     TableOperators.Or, subscriberNameQuery);
                }
                
            }

            var query = new TableQuery<SubscriptionRequest>()
               .Where(combinedFilters)
               .Take(MAX_ITEMS_TO_FETCH);

            var Token = default(TableContinuationToken);
            var subscriotionDataEntity = new List<SubscriptionRequest>();

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SubscriptionRequest>(query, Token);

                if (queryResult.Results.Count == 0)
                {
                    throw new Exception("No Data Found");
                }

                foreach (var item in queryResult.Results)
                {
                    if (item.FullDeliveryAddress != null || item.SchedullingDetails != null)
                    {
                        var addressReult = JsonConvert.DeserializeObject<Address[]>(item.FullDeliveryAddress);
                        item.DeliveryAddresses = addressReult;

                        var schedules = JsonConvert.DeserializeObject<SchedulingModel[]>(item.SchedullingDetails);
                        item.SchedullingInfo = schedules;
                    }

                }

                subscriotionDataEntity.Capacity += queryResult.Results.Count;
                subscriotionDataEntity.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;

                if (Token != null && query.TakeCount.HasValue)
                {
                    var itemsToLoad = query.TakeCount.Value - subscriotionDataEntity.Count;

                    query = itemsToLoad > 0 ? query.Take(itemsToLoad) : null;
                }

            } while (Token != null && query != null);


            return subscriotionDataEntity;
        }


       

        /// <summary>
        /// Subscription Cancelletion Request
        /// </summary>
        /// <param name="cancellationRequest"></param>
        /// <returns></returns>
        public async Task<bool> SubscriptionCancellationRequest(CancellationRequest cancellationRequest)
        {
            var status = default(bool);          
            var validation = cancellationRequest != default(CancellationRequest);          

            if (!validation)
                throw new ArgumentException("Invalid Argument");

            var existingData = await this.GetSubscriptionRequestDataById(cancellationRequest.companyId, cancellationRequest.requestId);

            var IsSubscriptionRequestStatsApproved = default(string);
            var IsSubscriptionRequestStatsRejected = default(string);
            var IsCancelApproved = default(string);
            var IsCancelRejected = default(string);


            if (existingData.Count != 0)
            {               
                foreach (var item in existingData)
                {
                    IsSubscriptionRequestStatsApproved = item.Status;
                    IsSubscriptionRequestStatsRejected = item.Status;
                    IsCancelApproved = item.ResponseCancellationStatus;
                    IsCancelRejected = item.ResponseCancellationStatus;

                    if (!(IsSubscriptionRequestStatsApproved.ToLower().Equals("approved") || IsSubscriptionRequestStatsRejected.ToLower().Equals("rejected")))
                    {
                        var tableOperation = default(dynamic);
                        if ((IsCancelApproved == null || IsCancelRejected == null) || !(IsCancelApproved.ToLower().Contains("cancellation approved") || IsCancelRejected.ToLower().Contains("cancellation rejected")))
                        {
                            if (cancellationRequest.RequestCancelDate < item.SubscriptionDate)
                            {
                                throw new Exception("Request Cancel Date should not be less the Subscription Date!");
                            }
                            item.RequestCancelDate = DateTime.Now.Date;
                            item.RequestCancelStatus = "cancellation requested";

                            item.RequestCancelReason = cancellationRequest.RequestCancelReason;
                            tableOperation = TableOperation.Replace(item);
                           
                            var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
                            var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };
                            status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);
                        }
                        else
                        {
                            if (IsCancelApproved.ToLower() == "cancellation approved")
                            {
                                status = false;
                                throw new Exception("Cancellation Request Status is Already Approved!");
                            }

                            if (IsCancelRejected.ToLower() == "cancellation rejected")
                            {
                                status = false;
                                throw new Exception("Cancellation Request Status is Already Rejected!");
                            }
                        }
                    }
                    else
                    {
                        status = false;
                        throw new ApplicationException("Subscription Request has already been Approved (or) Rejected!");
                    }
                }
            }
            else
            {
                status = false;
                throw new ArgumentException("No Data Found for the given RequestID and CompanyID " + " " 
                    + cancellationRequest.requestId, cancellationRequest.companyId + " " + " check the requestId, and companyid!");
            }

            return status;            
        }


        /// <summary>
        /// Admin Update's the Subscription Cancellations Request Respone
        /// </summary>
        /// <param name="cancellationResponse"></param>
        /// <returns></returns>
        public async Task<bool> UpdateSubscriptionCancellationResponse(CancellationResponse cancellationResponse)
        {
            var status = default(bool);
            // var validation = !string.IsNullOrEmpty(requestId) || !string.IsNullOrEmpty(responseCancelReason);
            var validation = cancellationResponse != default(CancellationResponse);

            if (!validation)
                throw new ArgumentException("Invalid Argument");           

            var IsUserAdmin = await this.IsUserAdminOrNot(cancellationResponse.companyId);

            if (IsUserAdmin == true)
            {
                //var existingData = await this.GetSubscriptionRequestDataById(cancellationResponse.companyId, cancellationResponse.requestId);
                var existingData = await this.GetRequestListByRequestId(cancellationResponse.requestId);

                var IsSubscriptionRequestStatsApproved = default(string);
                var IsSubscriptionRequestStatsRejected = default(string);
                var IsCancelApproved = default(string);
                var IsCancelRejected = default(string);

                if(existingData != null || existingData.Count() != 0) 
                {
                    foreach (var item in existingData)
                    {

                        IsSubscriptionRequestStatsApproved = item.Status;
                        IsSubscriptionRequestStatsRejected = item.Status;
                        IsCancelApproved = item.ResponseCancellationStatus;
                        IsCancelRejected = item.ResponseCancellationStatus;

                        if (!(IsSubscriptionRequestStatsApproved.ToLower().Contains("approved") || IsSubscriptionRequestStatsRejected.ToLower().Contains("rejected")))
                        {
                            if ((IsCancelApproved == null || IsCancelRejected == null) || !(IsCancelApproved.ToLower().Contains("cancellation approved") || IsCancelRejected.ToLower().Contains("cancellation rejected")))
                            {
                                var tableOperation = default(dynamic);
                                //if (existingData != default && existingData.Count() != 0)
                                //{
                                    //foreach (var item in existingData)
                                    //{
                                    if (cancellationResponse.ResponseCancellationDate < item.SubscriptionDate)
                                    {
                                        status = false;
                                        throw new Exception("Response Cancel Date should not be less the Subscription Date!");
                                    }
                                    item.ResponseCancellationDate = cancellationResponse.ResponseCancellationDate;
                                    item.ResponseCancellationReason = cancellationResponse.ResponseCancellationReason;
                                    item.ResponseCancellationStatus = cancellationResponse.ResponseCancellationStatus;
                                    tableOperation = TableOperation.Replace(item);
                                    //}
                                //}                                

                                var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
                                var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };
                                status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);

                                //var  result =  status;
                            }
                            else
                            {
                                if (IsCancelApproved.ToLower() == "cancellation approved")
                                {
                                    status = false;
                                    throw new Exception("Cancellation Request Response Status is Already Approved!");
                                }

                                if (IsCancelRejected.ToLower() == "cancellation rejected")
                                {
                                    status = false;
                                    throw new Exception("Cancellation Request Response Status is Already Rejected!");
                                }
                                
                            }
                        }
                        else
                        {
                            status = false;
                            throw new ApplicationException("Subscription Request has already been approved(or)rejected. You can't cancel Request!");
                        }
                    }

                }
                else
                {
                    status = false;
                    throw new ArgumentException("No Data Found for the given RequestID " + cancellationResponse.requestId + " " + " check the requestId");
                }
            }
            else
            {
                status = false;
                throw new Exception("Your are not a Authorized User to perform this action. Since, User is not a admin.");
            }
            return status;
        }


        /// <summary>
        /// To Get All the Request Lists
        /// </summary>
        /// <returns></returns>
        /// 
        public async Task<IEnumerable<SubscriptionRequest>> GetAllRequestsList()
        {
            var query = new TableQuery<SubscriptionRequest>();

            var Token = default(TableContinuationToken);
            var subscriptionRequestEntities = new List<SubscriptionRequest>();

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SubscriptionRequest>(query, Token);

                foreach (var item in queryResult.Results)
                {
                    if (item.FullDeliveryAddress != null || item.SchedullingDetails != null)
                    {
                        var addressReult = JsonConvert.DeserializeObject<Address[]>(item.FullDeliveryAddress);
                        item.DeliveryAddresses = addressReult;

                        var schedules = JsonConvert.DeserializeObject<SchedulingModel[]>(item.SchedullingDetails);
                        item.SchedullingInfo = schedules;
                    }
                }
                subscriptionRequestEntities.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;
            } while (Token != null);

            return subscriptionRequestEntities;
        }


        /// <summary>
        /// To Get All RequestsList By CompanyId for both Admin and USER
        /// </summary>
        /// <param name="CompanyId"></param>
        /// <returns></returns>
        /// 
        public async Task<IEnumerable<SubscriptionRequest>> GetAllRequestsListByCompanyId(string CompanyId)
        {
            var validation = !string.IsNullOrEmpty(CompanyId);
            var subscriotionDataEntity = new List<SubscriptionRequest>();

            if (!validation)
                throw new ArgumentException("Invalid Arguments");           


            var IsUserAdmin = await this.IsUserAdminOrNot(CompanyId);

            if (IsUserAdmin != true)
            {               
                var queryCondition = TableQuery.GenerateFilterCondition("CompanyId", QueryComparisons.Equal, CompanyId);
            //    var statusQuery = TableQuery.GenerateFilterCondition("Status", QueryComparisons.Equal, "approved");           

                var query = new TableQuery<SubscriptionRequest>().Where(queryCondition).Take(MAX_ITEMS_TO_FETCH);

                var Token = default(TableContinuationToken);

                do
                {
                    var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SubscriptionRequest>(query, Token);
                    if (queryResult.Results.Count == 0)
                    {
                        throw new Exception("No Data Found");
                    }

                    foreach (var item in queryResult.Results)
                    {
                        if (item.FullDeliveryAddress != null || item.SchedullingDetails != null)
                        {
                            var addressReult = JsonConvert.DeserializeObject<Address[]>(item.FullDeliveryAddress);
                            item.DeliveryAddresses = addressReult;

                            var schedules = JsonConvert.DeserializeObject<SchedulingModel[]>(item.SchedullingDetails);
                            item.SchedullingInfo = schedules;
                        }
                    }

                    subscriotionDataEntity.AddRange(queryResult.Results);
                    Token = queryResult.ContinuationToken;
                } while (Token != null && query != null);

                return subscriotionDataEntity;
            }
            else
            {
                return await this.GetAllRequestsList();
            }
        }

        /// <summary>
        /// To Get SubscriptionRequest Data By Filter Conditon
        /// </summary>
        /// <param name="companyId"></param>
        /// <param name="status"></param>
        /// <param name="search"></param>
        /// <param name="pagesize"></param>
        /// <param name="pageindex"></param>
        /// <returns></returns>
        public async Task<RequestDataList> GetSubscriptionRequestByFilter(string companyId, string status, string search, DateTime? startDate, DateTime? endDate, int pagesize, int pageindex)
        {
            RequestDataList requestDataList = null;
            try
            {
                requestDataList = await RequestDataByFilter(companyId,status,search,startDate,endDate, pagesize, pageindex);
            }
            catch(Exception ex) 
            {
                Console.WriteLine(ex);
                throw ex;
            }

            return requestDataList;
        }

        private async Task<RequestDataList> RequestDataByFilter(string companyId,string status,string search,DateTime? startDate,DateTime? endDate, int pagesize, int pageindex)
        {
             RequestDataList requestDataList = null;

            List<SubscriptionRequest> subscriptionRequestDataResult = new List<SubscriptionRequest>();
            List<SubscriptionRequest> filterdData = new List<SubscriptionRequest>();
            
            var message = "No Data Found";          

            if(companyId != null)
            {
                subscriptionRequestDataResult = (List<SubscriptionRequest>)await this.GetAllRequestsListByCompanyId(companyId);

                subscriptionRequestDataResult = subscriptionRequestDataResult.OrderByDescending(x => x.TotalOrderValue).ToList();
               // var filterData = subscriptionRequestDataResult.Where(x => x.SubscriptionDate >= startDate && x.SubscriptionDate <= endDate);
                //var highPriceRequests= subscriptionRequestDataResult.Where(x => x.SchedullingInfo.Where(i => i.DishesItems.Where(i => i.Cost.))

                foreach (var data in subscriptionRequestDataResult)
                {
                    if (data.IsActive == true)
                    {
                        if (status.ToLower().Equals("All".ToLower()))
                        {
                            if (data.CompanyName.ToLower().Contains(search.ToLower()) ||
                                data.RequestId.ToLower().Contains(search.ToLower()) ||
                                data.SubscriberName.ToLower().Contains(search.ToLower()) ||
                                data.EmailId.ToLower().Contains(search.ToLower()) ||
                                data.PhoneNumber.ToLower().Contains(search.ToLower()))
                            {
                                if (startDate == null || endDate == null)
                                {
                                    filterdData.Add(new SubscriptionRequest
                                    {
                                        RequestId = data.RequestId,
                                        CompanyId = data.CompanyId,
                                        CompanyName = data.CompanyName,
                                        SubscriberName = data.SubscriberName,
                                        EmailId = data.EmailId,
                                        PhoneNumber = data.PhoneNumber,
                                        DeliveryAddresses = data.DeliveryAddresses,
                                        SubscriptionDate = data.SubscriptionDate,
                                        ModifiedDate = data.ModifiedDate,
                                        SchedullingInfo = data.SchedullingInfo,
                                        PromoCode = data.PromoCode,
                                        TotalOrderValue = data.TotalOrderValue,
                                        Notes = data.Notes,
                                        IsActive = data.IsActive,
                                        IsDeleted = data.IsDeleted,
                                        Status = data.Status
                                    });
                                }
                                else
                                {
                                    if (data.SubscriptionDate >= startDate && data.SubscriptionDate <= endDate)
                                    {
                                        filterdData.Add(new SubscriptionRequest
                                        {
                                            RequestId = data.RequestId,
                                            CompanyId = data.CompanyId,
                                            CompanyName = data.CompanyName,
                                            SubscriberName = data.SubscriberName,
                                            EmailId = data.EmailId,
                                            PhoneNumber = data.PhoneNumber,
                                            DeliveryAddresses = data.DeliveryAddresses,
                                            SubscriptionDate = data.SubscriptionDate,
                                            ModifiedDate = data.ModifiedDate,
                                            SchedullingInfo = data.SchedullingInfo,
                                            PromoCode = data.PromoCode,
                                            TotalOrderValue = data.TotalOrderValue,
                                            Notes = data.Notes,
                                            IsActive = data.IsActive,
                                            IsDeleted = data.IsDeleted,
                                            Status = data.Status
                                        });
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine(message);
                            }
                        }
                        else if (data.Status.ToLower().Equals(status.ToLower()))
                        {
                            if (data.CompanyName.ToLower().Contains(search.ToLower()) ||
                                data.RequestId.ToLower().Contains(search.ToLower()) ||
                                data.SubscriberName.ToLower().Contains(search.ToLower()) ||
                                data.EmailId.ToLower().Contains(search.ToLower()) ||
                                data.PhoneNumber.ToLower().Contains(search.ToLower()))
                            {
                                if (startDate == null || startDate == null)
                                {
                                    filterdData.Add(new SubscriptionRequest
                                    {
                                        RequestId = data.RequestId,
                                        CompanyId = data.CompanyId,
                                        CompanyName = data.CompanyName,
                                        SubscriberName = data.SubscriberName,
                                        EmailId = data.EmailId,
                                        PhoneNumber = data.PhoneNumber,
                                        DeliveryAddresses = data.DeliveryAddresses,
                                        SubscriptionDate = data.SubscriptionDate,
                                        ModifiedDate = data.ModifiedDate,
                                        SchedullingInfo = data.SchedullingInfo,
                                        PromoCode = data.PromoCode,
                                        TotalOrderValue = data.TotalOrderValue,
                                        Notes = data.Notes,
                                        IsActive = data.IsActive,
                                        IsDeleted = data.IsDeleted,
                                        Status = data.Status
                                    });
                                }
                                else
                                {
                                    if (data.SubscriptionDate >= startDate && data.SubscriptionDate <= endDate)
                                    {
                                        filterdData.Add(new SubscriptionRequest
                                        {
                                            RequestId = data.RequestId,
                                            CompanyId = data.CompanyId,
                                            CompanyName = data.CompanyName,
                                            SubscriberName = data.SubscriberName,
                                            EmailId = data.EmailId,
                                            PhoneNumber = data.PhoneNumber,
                                            DeliveryAddresses = data.DeliveryAddresses,
                                            SubscriptionDate = data.SubscriptionDate,
                                            ModifiedDate = data.ModifiedDate,
                                            SchedullingInfo = data.SchedullingInfo,
                                            PromoCode = data.PromoCode,
                                            TotalOrderValue = data.TotalOrderValue,
                                            Notes = data.Notes,
                                            IsActive = data.IsActive,
                                            IsDeleted = data.IsDeleted,
                                            Status = data.Status
                                        });
                                    }
                                }

                            }
                            else
                            {
                                Console.WriteLine(message);
                            }
                        }
                    }
                }
            }                                
                       

            if (filterdData != null)
            {
                filterdData = filterdData.OrderByDescending(x => x.TotalOrderValue).Skip(pagesize * pageindex).Take(pagesize).ToList();
            }
            
            requestDataList = new RequestDataList 
            {
                RequestsList = filterdData,               
            };
            return requestDataList;
        }


        private async Task<bool> IsUserAdminOrNot(string companyId)
        {
            var IsValid = !string.IsNullOrEmpty(companyId);

            if (!IsValid)
                throw new ArgumentException("Invalid CompanyID");

            var companyDataById = await objCompRepo.GetCompanyDataByID(companyId);
            
            var IsUserAdmin = default(bool);
            foreach (var item in companyDataById) {

                IsUserAdmin = item.IsAdmin;
            }

            return IsUserAdmin;
        }

        /// <summary>
        /// To Get SubscriptionRequests Data By Status
        /// </summary>
        /// <param name="companyId"></param>
        /// <param name="statusString"></param>
        /// <returns></returns>
        /// 
        public async Task<List<SubscriptionRequest>> GetSubscriptionRequestDataByStatus(string companyId, string statusString)
        {
            var Isvalid = !string.IsNullOrEmpty(statusString) ||                
                !string.IsNullOrEmpty(companyId) ;                          
                
            if (!Isvalid)
                throw new ArgumentException("Invalid Argument");


            var queryCondition1 = default(string);
            var queryCondition2 = default(string);
            var combinedFilters = default(string);
            var subscriptionRequestEntities = new List<SubscriptionRequest>();

            var existingData = await this.GetAllRequestsListByCompanyId(companyId);

            var IsUserAdmin = await this.IsUserAdminOrNot(companyId);            

            foreach (var item in existingData)
            {
               var requestStauts = item.Status;
                
                if (item.Status.ToLower().Equals(statusString.ToLower()))
                {
                    if (!IsUserAdmin)
                    {
                        queryCondition1 = TableQuery.GenerateFilterCondition("CompanyId", QueryComparisons.Equal, item.CompanyId);
                        queryCondition2 = TableQuery.GenerateFilterCondition("Status", QueryComparisons.Equal, item.Status);

                        combinedFilters = TableQuery.CombineFilters(queryCondition1, TableOperators.And, queryCondition2);
                    }
                    else
                    {
                        combinedFilters = TableQuery.GenerateFilterCondition("Status", QueryComparisons.Equal, item.Status);
                    }

                    var query = new TableQuery<SubscriptionRequest>().Where(combinedFilters).Take(MAX_ITEMS_TO_FETCH);
                    var Token = default(TableContinuationToken);
                    subscriptionRequestEntities = new List<SubscriptionRequest>();

                    do
                    {
                        var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SubscriptionRequest>(query, Token);

                        if (queryResult.Results.Count == 0)
                        {
                            throw new Exception("No Data Found");
                        }

                        foreach (var result in queryResult.Results)
                        {
                            if (result.FullDeliveryAddress != null || result.SchedullingDetails != null)
                            {
                                var addressReult = JsonConvert.DeserializeObject<Address[]>(result.FullDeliveryAddress);
                                result.DeliveryAddresses = addressReult;

                                var schedules = JsonConvert.DeserializeObject<SchedulingModel[]>(result.SchedullingDetails);
                                result.SchedullingInfo = schedules;
                            }

                        }
                        subscriptionRequestEntities.AddRange(queryResult.Results);
                        Token = queryResult.ContinuationToken;
                    } while (Token != null);

                  //  return subscriptionRequestEntities;
                }                
            }          

            return subscriptionRequestEntities;
        }


        /// <summary>
        /// To Get RequestList By RequestId
        /// </summary>
        /// <param name="requestId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<SubscriptionRequest>> GetRequestListByRequestId(string requestId)
        {

            var Isvalid = !string.IsNullOrEmpty(requestId);

            if (!Isvalid)
                throw new ArgumentException("Invalid Argument");


            var queryCondition = default(dynamic);
           
            var subscriptionRequestEntities = new List<SubscriptionRequest>();

            queryCondition = TableQuery.GenerateFilterCondition("RequestId", QueryComparisons.Equal,requestId);                      

            var query = new TableQuery<SubscriptionRequest>().Where(queryCondition).Take(MAX_ITEMS_TO_FETCH);
            var Token = default(TableContinuationToken);
            subscriptionRequestEntities = new List<SubscriptionRequest>();

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SubscriptionRequest>(query, Token);

                //if (queryResult.Results.Count == 0)
                //{
                //    throw new Exception("No Data Found");
                //}

                foreach (var result in queryResult.Results)
                {
                    if (result.FullDeliveryAddress != null || result.SchedullingDetails != null)
                    {
                        var addressReult = JsonConvert.DeserializeObject<Address[]>(result.FullDeliveryAddress);
                        result.DeliveryAddresses = addressReult;

                        var schedules = JsonConvert.DeserializeObject<SchedulingModel[]>(result.SchedullingDetails);
                        result.SchedullingInfo = schedules;
                    }

                }
                subscriptionRequestEntities.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;
            } while (Token != null);          
                     
            return subscriptionRequestEntities;
        }

        /// <summary>
        /// To Get RequestList  By RequestId companyId
        /// </summary>
        /// <param name="requestId"></param>
        /// <param name="companyId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<SubscriptionRequest>> GetRequestListByIds(string requestId, string companyId)
        {
            var Isvalid = !string.IsNullOrEmpty(requestId);

            if (!Isvalid)
                throw new ArgumentException("Invalid Argument");


            var queryCondition1 = default(dynamic);
            var queryCondition2 = default(dynamic);

            var subscriptionRequestEntities = new List<SubscriptionRequest>();

            queryCondition1 = TableQuery.GenerateFilterCondition("RequestId", QueryComparisons.Equal, requestId);
            queryCondition2 = TableQuery.GenerateFilterCondition("CompanyId", QueryComparisons.Equal, companyId);

            var combineFilter = TableQuery.CombineFilters(queryCondition1, TableOperators.And, queryCondition2);

            var query = new TableQuery<SubscriptionRequest>().Where(combineFilter).Take(MAX_ITEMS_TO_FETCH);
            var Token = default(TableContinuationToken);
            subscriptionRequestEntities = new List<SubscriptionRequest>();

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SubscriptionRequest>(query, Token);

                //if (queryResult.Results.Count == 0)
                //{
                //    throw new Exception("No Data Found");
                //}

                foreach (var result in queryResult.Results)
                {
                    if (result.FullDeliveryAddress != null || result.SchedullingDetails != null)
                    {
                        var addressReult = JsonConvert.DeserializeObject<Address[]>(result.FullDeliveryAddress);
                        result.DeliveryAddresses = addressReult;

                        var schedules = JsonConvert.DeserializeObject<SchedulingModel[]>(result.SchedullingDetails);
                        result.SchedullingInfo = schedules;
                    }

                }
                subscriptionRequestEntities.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;
            } while (Token != null);

            return subscriptionRequestEntities;
        }


        public async Task<SubscriptionRequest> ReteriveRequestData(string partitionKey, string rowKey)
        {
            TableOperation tableOperation = TableOperation.Retrieve<SubscriptionRequest>(partitionKey, rowKey);
            TableResult tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
            return (SubscriptionRequest)tableResult.Result;
        }


        public async Task<bool> DeleteRequest(string companyId, string requestId)
        {
            var status = default(bool);
            var validation = !string.IsNullOrEmpty(requestId) &&
                                !string.IsNullOrEmpty(companyId);

            if (!validation)
                throw new ArgumentException("Invalid Arguments!");


            var tableEntity = await this.ReteriveRequestData(companyId, requestId);

            if (tableEntity == null)
            {
                status = false;
                throw new ArgumentException("No Data Found with given RequestId and CompnayId");
            }

            if (tableEntity.IsDeleted != true)
            {
                if (tableEntity != default)
                {
                    if (tableEntity.Status.ToLower().Equals("approved".ToLower()))
                    {
                        status = false;
                        throw new ApplicationException("Request Order is Already Approved. Can't be Deleted!");
                    }
                    else if (tableEntity.Status.ToLower().Equals("rejected".ToLower()))
                    {
                        status = false;
                        throw new ApplicationException("Request Order is Already Rejected. Can't be Deleted!");
                    }
                }


                if (tableEntity != default)
                {

                    tableEntity.IsActive = false;
                    tableEntity.IsDeleted = true;
                    tableEntity.ModifiedDate = DateTime.Now;
                }

                var tableOperation = TableOperation.Replace(tableEntity);
                var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
                var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };

                status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);
                return status;
            }
            else
            {
                throw new ApplicationException("No Data Found. Data is already Delete!");
            }
        }




    }

}
