﻿using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.DA.Interfaces;
using Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace Alphasource.Libs.FoodyHiveSub.Repositories.Impl
{
    public class SchedulingRepository : ISchedulingRepository
    {
        private const int MAX_ITEMS_TO_FETCH = 5000;

        private TableStorageSettings tableStorageSettings = default;
        private CloudStorageAccount cloudStorageAccount = default;
        private CloudTableClient cloudTableClient = default;
        private CloudTable cloudTable = default;


        private CompanySignUpRepository objCompRepo = default;


        public SchedulingRepository(TableStorageSettings tableStorageSettings)
        {
            var validateConnection = tableStorageSettings != default &&
                !string.IsNullOrEmpty(tableStorageSettings.ConnectionString) &&
                !string.IsNullOrEmpty(tableStorageSettings.TableName);

            if (!validateConnection)
            {
                throw new ArgumentException("INVALID_TABLE_STORAGE_SETTINGS");
            }

            this.tableStorageSettings = tableStorageSettings;
            this.cloudStorageAccount = CloudStorageAccount.Parse(this.tableStorageSettings.ConnectionString);
            this.cloudTableClient = this.cloudStorageAccount.CreateCloudTableClient();       
            this.cloudTable = this.cloudTableClient.GetTableReference("schedullingDishTableV2");
            this.objCompRepo = new CompanySignUpRepository(tableStorageSettings);
            CreateNewTable(cloudTable);

        }



        /// <summary>
        /// Create the New Azure Table Storage in the Azure Storage Account if Not Exists
        /// </summary>
        /// <param name="table"></param>
        /// 
        public async static void CreateNewTable(CloudTable table)
        {
            if (!await table.CreateIfNotExistsAsync())
            {
                Console.WriteLine("Table already exists");
                return;
            }
        }
        public async Task<SchedulingModel> CreateNewSchedule(SchedulingModel schedulingData)
        {
            //var status = default(bool);

            var result = default(SchedulingModel);
            var IsValidCompanyID = await this.IsCompanyIdExistsOrNot(schedulingData.CompanyID);
            if (IsValidCompanyID == true)
            {
                //Cretes the scheduleID
                #region
                string date = DateTime.Now.ToString("ddMMyyyyHHmmss");

                string finalStr = "SCHDE" + date;

                schedulingData.ScheduleID = finalStr;

                schedulingData.PartitionKey = schedulingData.ScheduleID;

                schedulingData.RowKey = schedulingData.CompanyID;

                schedulingData.ETag = new Random().Next(1, 10000000).ToString();

                schedulingData.CreatedDate = DateTime.Now;
                schedulingData.UpdatedDate = new DateTime(
                 DateTime.Now.Year, DateTime.Now.Month, 1, 0, 0, 0, DateTimeKind.Utc);
                #endregion

                var validation = schedulingData != default &&
                    !string.IsNullOrEmpty(schedulingData.CompanyID) &&
                    !string.IsNullOrEmpty(schedulingData.ScheduleID);

                if (!validation)
                    throw new ArgumentException("Invalid subscription Reuqest Entity");


                var tableOperation = TableOperation.Insert(schedulingData);
                var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);

                result = (SchedulingModel)tableResult.Result;
                // var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };

                //status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);
            }
            else
            {
                throw new ApplicationException("Invalid CompanyID is specified.Check the CompanyID!");
            }
            return result;
        }


        private async Task<bool> IsCompanyIdExistsOrNot(string companyID)
        {
           var IsExists = default(bool);
            var IsValid = !string.IsNullOrEmpty(companyID);

            if (!IsValid)
                throw new ArgumentException("Invalid Arguments!.");

            var companyRecord = await this.objCompRepo.GetCompanyDataByID(companyID);

            if(companyRecord.Count != 0)
            {
               IsExists = true;
            }
            else
            {
                IsExists = false;
            }

            return IsExists;

        }

        //public async Task<bool> DeleteSchedules(string companyID, string scheduleID)
        //{
        //    var status = default(bool);
        //    var validation = !string.IsNullOrEmpty(scheduleID) &&
        //                        !string.IsNullOrEmpty(companyID);

        //    if (!validation)
        //        throw new ArgumentException("Invalid Arguments!.");

        //    var tableEntity = await this.GetSchedulesByIds(companyID, scheduleID);
        //    var tableOperation = default(dynamic);
        //    if (tableEntity != default)
        //    {
        //        foreach (var item in tableEntity)
        //        {
        //            item.CreatedDate = item.CreatedDate;
        //            item.UpdatedDate = DateTime.Now;
        //            item.IsActive = false;
        //            tableOperation = TableOperation.Replace(item);
        //        }

        //    }

        //    var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
        //    var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };

        //    status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);
        //    return status;
        //}


        public async Task<SchedulingModel> ReteriveScheduleData(string partitionKey, string rowKey)
        {
            TableOperation tableOperation = TableOperation.Retrieve<SchedulingModel>(partitionKey, rowKey);
            TableResult tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
            return (SchedulingModel)tableResult.Result;
        }


        public async Task<List<SchedulingModel>> SchedulesListByCompanyID(string companyID)
        {
            var validation = !string.IsNullOrEmpty(companyID);
            var schedullingDataEntity = new List<SchedulingModel>();

            if (!validation)
                throw new ArgumentException("Invalid Arguments");

            var queryCondition = TableQuery.GenerateFilterCondition("CompanyID", QueryComparisons.Equal, companyID);          
            
            var query = new TableQuery<SchedulingModel>().Where(queryCondition).Take(MAX_ITEMS_TO_FETCH);

            var Token = default(TableContinuationToken);

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SchedulingModel>(query, Token);
                if (queryResult.Results.Count == 0)
                {
                    throw new Exception("No Data Found");
                }
                foreach (var item in queryResult.Results)
                {
                    if (item.DishesItem != null && item.ExclusionDatesValue != null && item.ExclusionWeeksValue != null && item.ItemsDeliveryTime != null)
                    {
                        var dishValues = JsonConvert.DeserializeObject<DishItems[]>(item.DishesItem);
                        item.DishesItems = dishValues;

                        var exclusionDates = JsonConvert.DeserializeObject<DateTime[]>(item.ExclusionDatesValue);
                        item.ExclusionDates = exclusionDates;

                        var exclusionWeeks = JsonConvert.DeserializeObject<DayOfWeek[]>(item.ExclusionWeeksValue);
                        item.ExclusionWeeks = exclusionWeeks;

                        var DeliveryTimeValues = JsonConvert.DeserializeObject<DeliveryTime[]>(item.ItemsDeliveryTime);
                        item.ItemDeliveryTime = DeliveryTimeValues;
                    }

                }
                schedullingDataEntity.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;
            } while (Token != null && query != null);

            return schedullingDataEntity;
        }


        public async Task<bool> DeleteSchedules(string companyID, string scheduleID)
        {
            var status = default(bool);
            var validation = !string.IsNullOrEmpty(scheduleID) &&
                                !string.IsNullOrEmpty(companyID);

            if (!validation)
                throw new ArgumentException("Invalid Arguments!.");

            var tableEntity = await this.ReteriveScheduleData(scheduleID, companyID);

            var tableOperation = TableOperation.Delete(tableEntity);
            var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
            var successTableResultCodes = new int[] { 200, 201, 202, 203, 204, 205 };

            status = Array.Exists<int>(successTableResultCodes, value => value == tableResult.HttpStatusCode);
            return status;
        }


        public async Task<List<SchedulingModel>> GetAllSchedules()
        {
            var query = new TableQuery<SchedulingModel>();

            var Token = default(TableContinuationToken);
            var SchedulingDataEntities = new List<SchedulingModel>();

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SchedulingModel>(query, Token);
                if (queryResult.Results.Count == 0)
                {
                    throw new Exception("No Data Found");
                }
                foreach (var item in queryResult.Results)
                {
                    if (item.DishesItem != null && item.ExclusionDatesValue != null && item.ExclusionWeeksValue != null && item.ItemsDeliveryTime != null)
                    {
                        var dishValues = JsonConvert.DeserializeObject<DishItems[]>(item.DishesItem);
                        item.DishesItems = dishValues;

                        var exclusionDates = JsonConvert.DeserializeObject<DateTime[]>(item.ExclusionDatesValue);
                        item.ExclusionDates = exclusionDates;

                        var exclusionWeeks = JsonConvert.DeserializeObject<DayOfWeek[]>(item.ExclusionWeeksValue);
                        item.ExclusionWeeks = exclusionWeeks;

                        var DeliveryTimeValues = JsonConvert.DeserializeObject<DeliveryTime[]>(item.ItemsDeliveryTime);
                        item.ItemDeliveryTime = DeliveryTimeValues;
                    }
                }
                SchedulingDataEntities.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;
            } while (Token != null);

            return SchedulingDataEntities;
        }

        public async Task<List<SchedulingModel>> GetSchedulesByIds(string companyID, string scheduleID)
        {
            var validation = !string.IsNullOrEmpty(companyID) || !string.IsNullOrEmpty(scheduleID);
            var schedullingDataEntity = new List<SchedulingModel>();

            if (!validation)
                throw new ArgumentException("Invalid Arguments");

            var queryCondition = TableQuery.GenerateFilterCondition("CompanyID", QueryComparisons.Equal, companyID);

            var qCondtion = TableQuery.GenerateFilterCondition("ScheduleID", QueryComparisons.Equal, scheduleID);

            var combineFilter = TableQuery.CombineFilters(queryCondition, TableOperators.And, qCondtion);

            var query = new TableQuery<SchedulingModel>().Where(combineFilter).Take(MAX_ITEMS_TO_FETCH);

            var Token = default(TableContinuationToken);

            do
            {
                var queryResult = await this.cloudTable.ExecuteQuerySegmentedAsync<SchedulingModel>(query, Token);
                if (queryResult.Results.Count == 0)
                {
                    throw new Exception("No Data Found");
                }
                foreach (var item in queryResult.Results)
                {
                    if(item.DishesItem != null && item.ExclusionDatesValue != null && item.ExclusionWeeksValue != null && item.ItemsDeliveryTime != null)
                    {
                        var dishValues = JsonConvert.DeserializeObject<DishItems[]>(item.DishesItem);
                        item.DishesItems = dishValues;

                        var exclusionDates = JsonConvert.DeserializeObject<DateTime[]>(item.ExclusionDatesValue);
                        item.ExclusionDates = exclusionDates;

                        var exclusionWeeks = JsonConvert.DeserializeObject<DayOfWeek[]>(item.ExclusionWeeksValue);
                        item.ExclusionWeeks = exclusionWeeks;

                        var DeliveryTimeValues = JsonConvert.DeserializeObject<DeliveryTime[]>(item.ItemsDeliveryTime);
                        item.ItemDeliveryTime = DeliveryTimeValues;
                    }
                    
                }
                schedullingDataEntity.AddRange(queryResult.Results);
                Token = queryResult.ContinuationToken;
            } while (Token != null && query != null);

            return schedullingDataEntity;
        }

        public async Task<SchedulingModel> UpdateExistingSchedule(SchedulingModel schedulingData)
        {
            var validation = schedulingData != default &&            
             !string.IsNullOrEmpty(schedulingData.ScheduleID);

            var result = default(SchedulingModel);

            if (!validation)
                throw new ArgumentException("Invalid subscription request data");

            var getExistingData = await this.GetSchedulesByIds(schedulingData.CompanyID, schedulingData.ScheduleID);

            var IsScheduleDeleted = default(bool);
            var createdDate = default(DateTime);

            if (getExistingData != null)
            {
                foreach (var item in getExistingData)
                {
                    //if(schedulingData.StartDate != item.StartDate)
                    //{
                    //    throw new ArgumentException("Your are not allowed to change the  Schedule Start Date!");
                    //}
                    createdDate = item.CreatedDate;
                    IsScheduleDeleted = item.IsActive;
                }
            }
            else
            {
                throw new Exception("No Data found");
            }


            if (IsScheduleDeleted != false)
            {
                if (string.IsNullOrEmpty(schedulingData.ETag))

                    schedulingData.ETag = "*";

                schedulingData.PartitionKey = schedulingData.ScheduleID;
                schedulingData.RowKey = schedulingData.CompanyID;
                schedulingData.CreatedDate = createdDate;
                schedulingData.UpdatedDate = DateTime.Now;

                var tableOperation = TableOperation.Replace(schedulingData);
                var tableResult = await this.cloudTable.ExecuteAsync(tableOperation);
                result = (SchedulingModel)tableResult.Result;
            }
            else
            {
                throw new Exception("schedule is delete and update can't be performed!");
            }

            return result;
        }
    }
}
