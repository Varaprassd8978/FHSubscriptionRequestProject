using Alphasource.Libs.FoodyHiveSub.Business.Impl;
using Alphasource.Libs.FoodyHiveSub.DA.Entities;
using Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces;
using Alphasource.Libs.FoodyHiveSub.Services.Impl;
using Moq;
using System;
using Xunit;

namespace Alphasource.Libs.FoodyHiveSub.Controllers.Impl.Tests
{
    public class SubRequestControllerTest
    {

        [Fact]
        public void Test1()
        {

        }

        //[Fact]
        //public async void ShouldAddSubscriptionRequestControllerActionWork()
        //{
        //    var mockSubscriptionRequest = new SubscriptionRequest
        //    {
        //        CompanyName = "SaVaRay Technologies",
        //        SubscriberName = "vara prasad",
        //        EmailId = "unittest@gmail.com",
        //        PhoneNumber = "8978305766",
        //        DeliveryAddress = new Address
        //        {
        //            AddressLine1 = "Marathahalli",
        //            AddressLine2 = "",
        //            City = "Banagalore",
        //            State = "Karnataka",
        //            Country = "India",
        //            PostalCode = "123456",
        //        },
        //        SubscriptionDate = DateTime.Now,
        //        DishPlan = new DishPlan[] {  },
        //        Plan = "request",
        //        DeliverySchedule = new Schedule[] { },
        //        TotalOrderValue = 100,
        //        Status = "Once Only"
        //    };


        //    foreach (var item in mockSubscriptionRequest.DishPlan)
        //    {
        //        item.DishItemName = "Biriyani";
        //        item.Description = "unit testing biriyani";
        //        item.NoOfUnits = 10;
        //        item.PackingCharges = 0;
        //        item.TaxValue = 0;
        //        item.Cost = 100;
        //        item.StartDate = new DateTime(2021,03,19);
        //        item.EndDate = new DateTime(2021, 03, 28);
        //        item.IsBreakfast = true;
        //        item.IsLunch = true;
        //        item.IsDinner = true;
        //        item.ExclusionDates = new DateTime[] 
        //        { 
        //            new DateTime(2021, 03, 20),
        //            new DateTime(2021, 03, 21)
        //        };
        //        item.ExclusionReason = "some thing";
        //    }

        //    foreach (var item1 in mockSubscriptionRequest.DeliverySchedule)
        //    {
        //        item1.Date = DateTime.Now;
        //        item1.PointOfContact = mockSubscriptionRequest.SubscriberName;
        //        item1.TimeRange = "01 : 00 PM";
        //    }

        //    var mockRepository = new MockRepository(MockBehavior.Default);

        //    var mockRequestService = mockRepository.Create<ISubscriptionRequestRepository>();

        //    mockRequestService.Setup(service => service.InsertNewSubscriprtionRequest(mockSubscriptionRequest)).ReturnsAsync(true);

        //    var requestController = new SubscriptionRequestService(mockRequestService.Object);

        //    var result = await requestController.InsertNewSubscriprtionRequest(mockSubscriptionRequest);

        //    Assert.False(result != true);

        //    Assert.IsType<bool>(result);
        //}

    }
}
