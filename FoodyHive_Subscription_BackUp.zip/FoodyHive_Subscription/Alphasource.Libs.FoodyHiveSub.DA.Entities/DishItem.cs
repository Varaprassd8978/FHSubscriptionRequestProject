﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Alphasource.Libs.FoodyHiveSub.DA.Entities
{
    public class DishItem
    {
        public string DishItemName { get; set; }
        public string Description { get; set; }
        public double Cost { get; set; }
        public int NoOfUnits { get; set; }
        public double TaxValue { get; set; }
        public double PackingCharges { get; set; }
        public double DeliveryCharges { get; set; }
        
        public override string ToString()
        {
            return string.Format(@"{0}, {1}, {2}, {3}, {4}, {5}, {6}",

                this.DishItemName, this.Description, this.Cost, this.NoOfUnits, this.TaxValue, this.PackingCharges, this.DeliveryCharges).ToString();
        }

    }

   
}
