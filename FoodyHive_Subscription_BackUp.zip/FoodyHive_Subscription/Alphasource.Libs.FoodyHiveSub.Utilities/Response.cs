﻿using System;

namespace Alphasource.Libs.FoodyHiveSub.Utilities
{
    public class Response
    {
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public string SuccessMessage { get; set; }
        public Object data { get; set; }
        public string Token { get; set; }
        public int Count { get; set; }

    }
}
