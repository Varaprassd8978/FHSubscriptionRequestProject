using Alphasource.Libs.FoodyHiveSub.Business.Impl;
using Alphasource.Libs.FoodyHiveSub.Business.Interfaces;
using Alphasource.Libs.FoodyHiveSub.DA.Interfaces;
using Alphasource.Libs.FoodyHiveSub.Reposiotries.Interfaces;
using Alphasource.Libs.FoodyHiveSub.Repositories.Impl;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.IdentityModel.Tokens;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alphasource.Hosting.FoodyHiveSub
{
    public class Startup
    {
        private const string CONNECTION_STRING = "TABLE_STORAGE_CONNECTION_STRING";
        private const string TABLE_NAME = "TABLE_NAME";

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            //  Environment Variables Validation and Settings
            //var ConnectionString =
            //    Environment.GetEnvironmentVariable(CONNECTION_STRING);
            //if (string.IsNullOrEmpty(ConnectionString))
            //   throw new ApplicationException("Invalid Table Storage Connection String");

            //var subscriptionRequestTableName = Environment.GetEnvironmentVariable(TABLE_NAME);

            //if (string.IsNullOrEmpty(subscriptionRequestTableName))
            //    throw new ApplicationException("Invaild Table Name");

            //services.AddScoped<TableStorageSettings>(serviceProvider =>
            //{
            //    var tableStorageSettings = new TableStorageSettings
            //    {
            //        ConnectionString = ConnectionString,
            //        TableName = subscriptionRequestTableName
            //    };

            //    return tableStorageSettings;
            //});

            services.Configure<TableStorageSettings>(
             options => {

                 options.ConnectionString = Configuration["TableStorage:TABLE_STORAGE_CONNECTION_STRING"];
                 Console.WriteLine(options.ConnectionString);

                 options.TableName = Configuration["TableStorage:TABLE_NAME"];
                 Console.WriteLine(options.TableName);
             });

            services.AddSingleton<TableStorageSettings>(serviceprovider =>
            {
                var tablestoragesettings = new TableStorageSettings
                {
                    ConnectionString = Configuration["TableStorage:TABLE_STORAGE_CONNECTION_STRING"],
                    TableName = Configuration["TableStorage:TABLE_NAME"]
                };

                return tablestoragesettings;
            });       

            services.AddScoped<ISubscriptionRequestService, SubscriptionRequestService>();
            services.AddScoped<ISubscriptionRequestRepository, SubscriptionRequestRepository>();

            services.AddScoped<IUserLoginService, UserLoginService>();
            services.AddScoped<IUserLoginRepository, UserLoginRepository>();
            
            services.AddScoped<ICompanySignUpService, CompanySignUpService>();
            services.AddScoped<ICompanySignUpRepository, CompanySignUpRepository>();

            services.AddScoped<ISchedulingRepository, SchedulingRepository>();
            services.AddScoped<ISchedulingService, SchedulingService>();


            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(bearerOptions =>
                {
                    bearerOptions.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = false,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = this.Configuration["Jwt:Issuer"],
                        ValidAudience = this.Configuration["Jwt:Issuer"],
                        IssuerSigningKey = new SymmetricSecurityKey(
                             Encoding.UTF8.GetBytes(this.Configuration["Jwt:Key"]))
                    };
                });

            services.AddSwaggerGen(swaggerGenOption =>
            {
                swaggerGenOption.SwaggerDoc("v2-v1", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "SubscriptionRequest API",
                    Version = "v2-v1",
                    Contact = new Microsoft.OpenApi.Models.OpenApiContact
                    {
                        Email = "service-ref@alphasource.com",
                        Name = "AlphaSource Engineering Team",
                        Url = new Uri(@"https://engineering.alphasource.com/promocode")
                    },
                    Description = "Simple Subscription Request API",
                    License = new Microsoft.OpenApi.Models.OpenApiLicense
                    {
                        Name = "Apache 2.0",
                        Url = new Uri(@"https://services.alphasource.com/license")
                    },
                    TermsOfService = new Uri(@"https://services.alphasource.com/terms")
                });

                //var filePath = Path.Combine(PlatformServices.Default.Application.ApplicationBasePath, @"Alphasource.Libs.FoodyHiveSub.Services.Impl.xml");

                //swaggerGenOption.IncludeXmlComments(filePath);

            });

            services.AddControllers();


            //services.AddAuthorization(config =>
            //{
            //    var policy = new AuthorizationPolicyBuilder()
            //                 .RequireAuthenticatedUser()
            //                 .Build();
            //    config.AddPolicy("defaultPolicy", policy);
            //});            

            services.AddCors(options => options.AddPolicy("CROS", corsPolicyBuilder =>
            {
                corsPolicyBuilder.SetIsOriginAllowed(x => true)
                                 .AllowAnyMethod()
                                 .AllowAnyHeader();
            }));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();
            app.UseSwaggerUI(
                swaggerUIOptions =>
                {
                    swaggerUIOptions.DefaultModelsExpandDepth(-1);
                    swaggerUIOptions.RoutePrefix = "";
                    swaggerUIOptions.SwaggerEndpoint("/swagger/v2-v1/swagger.json", "SubscriptionRequest API v2-v1");
                });

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseCors("CROS");

            app.UseAuthentication();
            app.UseAuthorization();           

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
